import { CourseType, SessionType } from '../types/academic';

export const BTECH_DEPARTMENTS = [
  'Computer Science & Engineering (CSE)',
  'Information Technology (IT)',
  'Electronics & Communication Engineering (ECE)',
  'Electrical Engineering (EE)',
  'Mechanical Engineering (ME)',
  'Civil Engineering (CE)',
  'Artificial Intelligence & Machine Learning (AI/ML)',
  'Artificial Intelligence & Data Science (AI & DS)',
  'Electronics Engineering',
  'Chemical Engineering',
  'Biotechnology',
  'Other',
] as const;

export const DIPLOMA_DEPARTMENTS = [
  'Computer Science & Technology / CST',
  'Computer Engineering',
  'Information Technology',
  'Electronics & Telecommunication',
  'Electrical Engineering',
  'Mechanical Engineering',
  'Civil Engineering',
  'Automobile Engineering',
  'Electronics Engineering',
  'Other',
] as const;

export const BTECH_YEARS = [
  '1st Year',
  '2nd Year',
  '3rd Year',
  '4th Year',
] as const;

export const DIPLOMA_YEARS = [
  '1st Year',
  '2nd Year',
  '3rd Year',
] as const;

export const BTECH_SEMESTERS_BY_YEAR: Record<string, string[]> = {
  '1st Year': ['Semester 1', 'Semester 2'],
  '2nd Year': ['Semester 3', 'Semester 4'],
  '3rd Year': ['Semester 5', 'Semester 6'],
  '4th Year': ['Semester 7', 'Semester 8'],
};

export const DIPLOMA_SEMESTERS_BY_YEAR: Record<string, string[]> = {
  '1st Year': ['Semester 1', 'Semester 2'],
  '2nd Year': ['Semester 3', 'Semester 4'],
  '3rd Year': ['Semester 5', 'Semester 6'],
};

export const ALL_BTECH_SEMESTERS = [
  'Semester 1',
  'Semester 2',
  'Semester 3',
  'Semester 4',
  'Semester 5',
  'Semester 6',
  'Semester 7',
  'Semester 8',
];

export const ALL_DIPLOMA_SEMESTERS = [
  'Semester 1',
  'Semester 2',
  'Semester 3',
  'Semester 4',
  'Semester 5',
  'Semester 6',
];

export const SESSION_TYPES: SessionType[] = [
  'Lecture',
  'Practical',
  'Lab',
  'Tutorial',
  'Assignment',
  'Revision',
  'Exam Preparation',
  'Project',
  'Other',
];

export const SUBJECT_COLORS = [
  { name: 'Indigo', value: '#4f46e5', bg: 'bg-indigo-50', text: 'text-indigo-700', border: 'border-indigo-200' },
  { name: 'Emerald', value: '#059669', bg: 'bg-emerald-50', text: 'text-emerald-700', border: 'border-emerald-200' },
  { name: 'Sky', value: '#0284c7', bg: 'bg-sky-50', text: 'text-sky-700', border: 'border-sky-200' },
  { name: 'Amber', value: '#d97706', bg: 'bg-amber-50', text: 'text-amber-700', border: 'border-amber-200' },
  { name: 'Rose', value: '#e11d48', bg: 'bg-rose-50', text: 'text-rose-700', border: 'border-rose-200' },
  { name: 'Purple', value: '#7c3aed', bg: 'bg-purple-50', text: 'text-purple-700', border: 'border-purple-200' },
  { name: 'Teal', value: '#0d9488', bg: 'bg-teal-50', text: 'text-teal-700', border: 'border-teal-200' },
  { name: 'Orange', value: '#ea580c', bg: 'bg-orange-50', text: 'text-orange-700', border: 'border-orange-200' },
  { name: 'Slate', value: '#475569', bg: 'bg-slate-100', text: 'text-slate-700', border: 'border-slate-300' },
];

export function getDepartmentsForCourse(course: CourseType | string): string[] {
  if (course === 'B.Tech') {
    return [...BTECH_DEPARTMENTS];
  }
  if (course === 'Diploma') {
    return [...DIPLOMA_DEPARTMENTS];
  }
  return [...BTECH_DEPARTMENTS, ...DIPLOMA_DEPARTMENTS.filter(d => !BTECH_DEPARTMENTS.includes(d as any))];
}

export function getYearsForCourse(course: CourseType | string): string[] {
  if (course === 'B.Tech') {
    return [...BTECH_YEARS];
  }
  if (course === 'Diploma') {
    return [...DIPLOMA_YEARS];
  }
  return ['1st Year', '2nd Year', '3rd Year', '4th Year'];
}

export function getSemestersForCourseAndYear(course: CourseType | string, year?: string): string[] {
  if (course === 'B.Tech') {
    if (year && BTECH_SEMESTERS_BY_YEAR[year]) {
      return BTECH_SEMESTERS_BY_YEAR[year];
    }
    return ALL_BTECH_SEMESTERS;
  }
  if (course === 'Diploma') {
    if (year && DIPLOMA_SEMESTERS_BY_YEAR[year]) {
      return DIPLOMA_SEMESTERS_BY_YEAR[year];
    }
    return ALL_DIPLOMA_SEMESTERS;
  }
  return ['Semester 1', 'Semester 2', 'Semester 3', 'Semester 4', 'Semester 5', 'Semester 6', 'Semester 7', 'Semester 8'];
}
