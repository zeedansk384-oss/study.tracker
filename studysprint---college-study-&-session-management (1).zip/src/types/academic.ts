export type CourseType = 'B.Tech' | 'Diploma' | 'Other';

export type SessionType =
  | 'Lecture'
  | 'Practical'
  | 'Lab'
  | 'Tutorial'
  | 'Assignment'
  | 'Revision'
  | 'Exam Preparation'
  | 'Project'
  | 'Other';

export type SessionStatus =
  | 'Scheduled'
  | 'In Progress'
  | 'Completed'
  | 'Cancelled'
  | 'Rescheduled';

export interface Subject {
  id: string;
  code: string;
  name: string;
  course: CourseType;
  department: string;
  year: string;
  semester: string;
  color: string;
  defaultTeacher?: string;
  defaultRoom?: string;
  credits?: number;
  description?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Session {
  id: string;
  title: string;
  subjectId: string;
  subjectName: string;
  subjectCode?: string;
  course: CourseType;
  department: string;
  year: string;
  semester: string;
  date: string; // YYYY-MM-DD
  startTime: string; // HH:mm (24-hour format)
  endTime: string; // HH:mm (24-hour format)
  sessionType: SessionType;
  customSessionType?: string;
  teacher?: string;
  room?: string;
  notes?: string;
  status: SessionStatus;
  color: string;
  createdAt: string;
  updatedAt: string;
}

export interface AcademicFilterState {
  course: string;
  department: string;
  year: string;
  semester: string;
  subjectId: string;
  sessionType: string;
  status: string;
  date?: string;
  searchQuery: string;
}

export interface UserPreferences {
  defaultCourse: CourseType;
  defaultDepartment: string;
  defaultYear: string;
  defaultSemester: string;
  defaultSessionDuration: number; // in minutes
  defaultSessionType: SessionType;
  calendarStartHour: number; // e.g. 8 for 08:00
  calendarEndHour: number; // e.g. 20 for 20:00
}
