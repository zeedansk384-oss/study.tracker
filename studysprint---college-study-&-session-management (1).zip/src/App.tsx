import React, { useState, useEffect } from 'react';
import {
  Subject,
  Session,
  UserPreferences,
  AcademicFilterState,
  CourseType,
  SessionStatus,
} from './types/academic';
import { storageService, formatDate } from './services/storageService';
import { Sidebar, ActiveTab } from './components/Sidebar';
import { AcademicFilterBar } from './components/AcademicFilterBar';
import { DashboardView } from './components/DashboardView';
import { CalendarView } from './components/CalendarView';
import { SessionsView } from './components/SessionsView';
import { SubjectsView } from './components/SubjectsView';
import { CoursesView } from './components/CoursesView';
import { SettingsView } from './components/SettingsView';
import { SessionModal } from './components/SessionModal';
import { QuickTimeEditModal } from './components/QuickTimeEditModal';
import { SubjectModal } from './components/SubjectModal';
import { ConfirmDeleteModal } from './components/ConfirmDeleteModal';
import { Menu, Plus, GraduationCap } from 'lucide-react';

export default function App() {
  // State
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [sessions, setSessions] = useState<Session[]>([]);
  const [preferences, setPreferences] = useState<UserPreferences>(() =>
    storageService.getPreferences()
  );
  const [activeTab, setActiveTab] = useState<ActiveTab>('sessions');

  // Dark mode state
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    return localStorage.getItem('studysprint_dark_mode') === 'true';
  });

  // Mobile sidebar open state
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  // Sync dark mode class with <html> element
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('studysprint_dark_mode', 'true');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('studysprint_dark_mode', 'false');
    }
  }, [darkMode]);

  const handleToggleDarkMode = () => {
    setDarkMode((prev) => !prev);
  };

  // Academic Filter State
  const [filters, setFilters] = useState<AcademicFilterState>({
    course: 'All',
    department: 'All',
    year: 'All',
    semester: 'All',
    subjectId: 'All',
    sessionType: 'All',
    status: 'All',
    searchQuery: '',
  });

  // Modal states
  const [isSessionModalOpen, setIsSessionModalOpen] = useState(false);
  const [editingSession, setEditingSession] = useState<Session | null>(null);
  const [sessionModalDefaultDate, setSessionModalDefaultDate] = useState<string | undefined>();

  const [isQuickTimeModalOpen, setIsQuickTimeModalOpen] = useState(false);
  const [targetTimeSession, setTargetTimeSession] = useState<Session | null>(null);

  const [isSubjectModalOpen, setIsSubjectModalOpen] = useState(false);
  const [editingSubject, setEditingSubject] = useState<Subject | null>(null);

  const [deleteConfirmation, setDeleteConfirmation] = useState<{
    isOpen: boolean;
    type: 'session' | 'subject';
    targetSession?: Session;
    targetSubject?: Subject;
  }>({
    isOpen: false,
    type: 'session',
  });

  // Load initial data from localStorage
  const loadData = () => {
    const loadedSubjects = storageService.getSubjects();
    const loadedSessions = storageService.getSessions();
    const loadedPrefs = storageService.getPreferences();
    setSubjects(loadedSubjects);
    setSessions(loadedSessions);
    setPreferences(loadedPrefs);
  };

  useEffect(() => {
    loadData();
  }, []);

  // Filtered Sessions for Views
  const filteredSessions = sessions.filter((s) => {
    if (filters.course !== 'All' && s.course !== filters.course) return false;
    if (filters.department !== 'All' && s.department !== filters.department) return false;
    if (filters.year !== 'All' && s.year !== filters.year) return false;
    if (filters.semester !== 'All' && s.semester !== filters.semester) return false;
    if (filters.subjectId !== 'All' && s.subjectId !== filters.subjectId) return false;
    if (filters.sessionType !== 'All' && s.sessionType !== filters.sessionType) return false;
    if (filters.status !== 'All' && s.status !== filters.status) return false;
    if (filters.date && s.date !== filters.date) return false;
    if (filters.searchQuery) {
      const q = filters.searchQuery.toLowerCase();
      const match =
        s.title.toLowerCase().includes(q) ||
        s.subjectName.toLowerCase().includes(q) ||
        (s.teacher && s.teacher.toLowerCase().includes(q)) ||
        (s.room && s.room.toLowerCase().includes(q)) ||
        (s.notes && s.notes.toLowerCase().includes(q));
      if (!match) return false;
    }
    return true;
  });

  // Session Handlers
  const handleOpenAddSession = (defaultDate?: string, defaultStartTime?: string) => {
    setEditingSession(null);
    setSessionModalDefaultDate(defaultDate || formatDate(new Date()));
    setIsSessionModalOpen(true);
  };

  const handleEditSession = (session: Session) => {
    setEditingSession(session);
    setSessionModalDefaultDate(session.date);
    setIsSessionModalOpen(true);
  };

  const handleSaveSession = (
    sessionData: Omit<Session, 'id' | 'createdAt' | 'updatedAt'> | Session
  ) => {
    if ('id' in sessionData) {
      storageService.updateSession(sessionData as Session);
    } else {
      storageService.saveSession(sessionData);
    }
    setSessions(storageService.getSessions());
  };

  // Dedicated single-session time change handler - Requirement #5
  const handleOpenQuickTimeEdit = (session: Session) => {
    setTargetTimeSession(session);
    setIsQuickTimeModalOpen(true);
  };

  const handleSaveQuickTime = (
    id: string,
    updates: {
      date: string;
      startTime: string;
      endTime: string;
      status?: SessionStatus;
    }
  ) => {
    storageService.updateSessionTime(id, updates);
    setSessions(storageService.getSessions());
  };

  // Duplicate session
  const handleDuplicateSession = (session: Session) => {
    storageService.duplicateSession(session.id);
    setSessions(storageService.getSessions());
  };

  // Delete session
  const handleDeleteSessionPrompt = (session: Session) => {
    setDeleteConfirmation({
      isOpen: true,
      type: 'session',
      targetSession: session,
    });
  };

  const handleConfirmDelete = () => {
    if (deleteConfirmation.type === 'session' && deleteConfirmation.targetSession) {
      storageService.deleteSession(deleteConfirmation.targetSession.id);
      setSessions(storageService.getSessions());
    } else if (deleteConfirmation.type === 'subject' && deleteConfirmation.targetSubject) {
      storageService.deleteSubject(deleteConfirmation.targetSubject.id, false);
      setSubjects(storageService.getSubjects());
      setSessions(storageService.getSessions());
    }
    setDeleteConfirmation({ isOpen: false, type: 'session' });
  };

  // Toggle session status
  const handleToggleComplete = (session: Session) => {
    const newStatus: SessionStatus =
      session.status === 'Completed' ? 'Scheduled' : 'Completed';
    storageService.updateSessionTime(session.id, { status: newStatus });
    setSessions(storageService.getSessions());
  };

  const handleStatusChange = (session: Session, newStatus: SessionStatus) => {
    storageService.updateSessionTime(session.id, { status: newStatus });
    setSessions(storageService.getSessions());
  };

  // Subject Handlers
  const handleOpenAddSubject = () => {
    setEditingSubject(null);
    setIsSubjectModalOpen(true);
  };

  const handleEditSubject = (subject: Subject) => {
    setEditingSubject(subject);
    setIsSubjectModalOpen(true);
  };

  const handleSaveSubject = (
    subjectData: Omit<Subject, 'id' | 'createdAt' | 'updatedAt'> | Subject
  ) => {
    if ('id' in subjectData) {
      storageService.updateSubject(subjectData as Subject);
    } else {
      storageService.saveSubject(subjectData);
    }
    setSubjects(storageService.getSubjects());
    setSessions(storageService.getSessions());
  };

  const handleDeleteSubjectPrompt = (subject: Subject) => {
    setDeleteConfirmation({
      isOpen: true,
      type: 'subject',
      targetSubject: subject,
    });
  };

  // Quick schedule from Subject Card
  const handleQuickAddSessionForSubject = (subject: Subject) => {
    const today = formatDate(new Date());
    const newSessionData: Omit<Session, 'id' | 'createdAt' | 'updatedAt'> = {
      title: `${subject.name} - Lecture`,
      subjectId: subject.id,
      subjectName: subject.name,
      subjectCode: subject.code,
      course: subject.course,
      department: subject.department,
      year: subject.year,
      semester: subject.semester,
      date: today,
      startTime: '10:00',
      endTime: '11:00',
      sessionType: 'Lecture',
      teacher: subject.defaultTeacher,
      room: subject.defaultRoom,
      status: 'Scheduled',
      color: subject.color,
    };
    storageService.saveSession(newSessionData);
    setSessions(storageService.getSessions());
    setActiveTab('sessions');
  };

  // Preferences & Data Reset
  const handleSavePreferences = (prefs: UserPreferences) => {
    storageService.savePreferences(prefs);
    setPreferences(prefs);
  };

  const handleResetData = () => {
    storageService.resetToDemoData();
    loadData();
  };

  const handleSelectSubjectFilter = (subId: string) => {
    setFilters((prev) => ({
      ...prev,
      subjectId: subId,
    }));
    setActiveTab('sessions');
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors">
      {/* Left Sidebar Navigation */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        darkMode={darkMode}
        onToggleDarkMode={handleToggleDarkMode}
        totalSessionsCount={sessions.length}
        mobileOpen={mobileSidebarOpen}
        onCloseMobile={() => setMobileSidebarOpen(false)}
      />

      {/* Main Content Area (offset by sidebar on desktop) */}
      <div className="lg:pl-64 flex flex-col flex-1 min-w-0">
        {/* Mobile Header Bar */}
        <header className="lg:hidden sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileSidebarOpen(true)}
              type="button"
              className="p-1.5 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 focus:outline-none"
              aria-label="Open Navigation"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-indigo-600 text-white flex items-center justify-center">
                <GraduationCap className="w-4 h-4" />
              </div>
              <span className="font-extrabold text-base text-indigo-700 dark:text-indigo-400">
                StudySprint
              </span>
            </div>
          </div>

          <button
            onClick={() => handleOpenAddSession()}
            type="button"
            className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 rounded-lg shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add</span>
          </button>
        </header>

        {/* View Content Body */}
        <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
          {/* External Filter bar on Dashboard & Calendar */}
          {(activeTab === 'dashboard' || activeTab === 'calendar') && (
            <AcademicFilterBar
              filters={filters}
              onFilterChange={setFilters}
              subjects={subjects}
            />
          )}

          {/* Views */}
          {activeTab === 'dashboard' && (
            <DashboardView
              sessions={sessions}
              subjects={subjects}
              filters={filters}
              onFilterChange={setFilters}
              onOpenAddSession={() => handleOpenAddSession()}
              onEditSession={handleEditSession}
              onQuickEditTime={handleOpenQuickTimeEdit}
              onDuplicateSession={handleDuplicateSession}
              onDeleteSession={handleDeleteSessionPrompt}
              onToggleComplete={handleToggleComplete}
              onNavigateToTab={setActiveTab}
            />
          )}

          {activeTab === 'sessions' && (
            <SessionsView
              sessions={filteredSessions}
              subjects={subjects}
              filters={filters}
              onFilterChange={setFilters}
              onOpenAddSession={() => handleOpenAddSession()}
              onEditSession={handleEditSession}
              onQuickEditTime={handleOpenQuickTimeEdit}
              onDuplicateSession={handleDuplicateSession}
              onDeleteSession={handleDeleteSessionPrompt}
              onStatusChange={handleStatusChange}
            />
          )}

          {activeTab === 'calendar' && (
            <CalendarView
              sessions={filteredSessions}
              subjects={subjects}
              onOpenAddSessionWithDate={(date, startTime) =>
                handleOpenAddSession(date, startTime)
              }
              onEditSession={handleEditSession}
              onQuickEditTime={handleOpenQuickTimeEdit}
              onDeleteSession={handleDeleteSessionPrompt}
              onToggleComplete={handleToggleComplete}
            />
          )}

          {activeTab === 'subjects' && (
            <SubjectsView
              subjects={subjects}
              sessions={sessions}
              onOpenAddSubject={handleOpenAddSubject}
              onEditSubject={handleEditSubject}
              onDeleteSubject={handleDeleteSubjectPrompt}
              onQuickAddSessionForSubject={handleQuickAddSessionForSubject}
            />
          )}

          {activeTab === 'courses' && (
            <CoursesView
              subjects={subjects}
              sessions={sessions}
              onOpenAddSubject={handleOpenAddSubject}
              onOpenAddSession={() => handleOpenAddSession()}
              onSelectSubjectFilter={handleSelectSubjectFilter}
            />
          )}

          {activeTab === 'settings' && (
            <SettingsView
              preferences={preferences}
              onSavePreferences={handleSavePreferences}
              onDataImported={loadData}
              onResetData={handleResetData}
            />
          )}
        </main>

        {/* Footer */}
        <footer className="border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 py-4 mt-auto">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 dark:text-slate-400 gap-2">
            <div>
              <strong>StudySprint</strong> · College Study & Session Management for B.Tech & Diploma
            </div>
            <div className="font-mono tabular-nums">
              {subjects.length} Subjects · {sessions.length} Saved Sessions · Local Persistent Storage
            </div>
          </div>
        </footer>
      </div>

      {/* Modals */}
      {/* 1. Full Session Add / Edit Modal */}
      <SessionModal
        isOpen={isSessionModalOpen}
        onClose={() => setIsSessionModalOpen(false)}
        onSave={handleSaveSession}
        initialSession={editingSession}
        subjects={subjects}
        onOpenAddSubject={() => {
          setIsSessionModalOpen(false);
          setIsSubjectModalOpen(true);
        }}
        defaultDate={sessionModalDefaultDate}
        defaultCourse={
          filters.course !== 'All' ? (filters.course as CourseType) : preferences.defaultCourse
        }
      />

      {/* 2. Fast Single-Session Time Change Modal (Requirement #5) */}
      <QuickTimeEditModal
        isOpen={isQuickTimeModalOpen}
        onClose={() => setIsQuickTimeModalOpen(false)}
        session={targetTimeSession}
        onSaveTime={handleSaveQuickTime}
      />

      {/* 3. Subject Add / Edit Modal */}
      <SubjectModal
        isOpen={isSubjectModalOpen}
        onClose={() => setIsSubjectModalOpen(false)}
        onSave={handleSaveSubject}
        initialSubject={editingSubject}
        defaultCourse={
          filters.course !== 'All' ? (filters.course as CourseType) : preferences.defaultCourse
        }
      />

      {/* 4. Confirmation Dialog */}
      <ConfirmDeleteModal
        isOpen={deleteConfirmation.isOpen}
        onClose={() => setDeleteConfirmation({ isOpen: false, type: 'session' })}
        onConfirm={handleConfirmDelete}
        title={
          deleteConfirmation.type === 'session'
            ? 'Delete Study Session?'
            : 'Delete Curriculum Subject?'
        }
        message={
          deleteConfirmation.type === 'session'
            ? 'Are you sure you want to delete this study session? This action cannot be undone.'
            : 'Are you sure you want to delete this subject? Sessions linked to this subject will remain in your calendar.'
        }
        itemName={
          deleteConfirmation.type === 'session'
            ? deleteConfirmation.targetSession?.title
            : deleteConfirmation.targetSubject?.name
        }
      />
    </div>
  );
}
