import { Subject, Session, UserPreferences, CourseType } from '../types/academic';

const SESSIONS_KEY = 'studysprint_sessions_v1';
const SUBJECTS_KEY = 'studysprint_subjects_v1';
const PREFS_KEY = 'studysprint_prefs_v1';

// Helper to format Date to YYYY-MM-DD in local time
export function formatDate(d: Date): string {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

// Helper to convert 24h "HH:mm" to 12h "hh:mm AM/PM"
export function formatTime12h(time24: string): string {
  if (!time24) return '';
  const [hStr, mStr] = time24.split(':');
  let h = parseInt(hStr, 10);
  const m = mStr || '00';
  if (isNaN(h)) return time24;
  const ampm = h >= 12 ? 'PM' : 'AM';
  h = h % 12;
  h = h ? h : 12;
  return `${h}:${m} ${ampm}`;
}

export function formatTimeRange(startTime: string, endTime: string): string {
  if (!startTime || !endTime) return '';
  return `${formatTime12h(startTime)} – ${formatTime12h(endTime)}`;
}

// Generate demo subjects
export function getInitialDemoSubjects(): Subject[] {
  const now = new Date().toISOString();
  return [
    {
      id: 'sub-btech-math',
      code: 'BS101',
      name: 'Mathematics',
      course: 'B.Tech',
      department: 'Computer Science & Engineering (CSE)',
      year: '1st Year',
      semester: 'Semester 1',
      color: '#4f46e5', // indigo
      defaultTeacher: 'Dr. S. K. Rao',
      defaultRoom: 'Room 101',
      credits: 4,
      description: 'Differential calculus, linear algebra, vector spaces, and matrices review.',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: 'sub-btech-cprog',
      code: 'CS102',
      name: 'Programming in C',
      course: 'B.Tech',
      department: 'Computer Science & Engineering (CSE)',
      year: '1st Year',
      semester: 'Semester 1',
      color: '#0284c7', // sky blue
      defaultTeacher: 'Prof. Ananya Sen',
      defaultRoom: 'Computing Lab 2',
      credits: 4,
      description: 'Pointers, dynamic memory allocation, structs, file handling, and algorithms in C.',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: 'sub-btech-1',
      code: 'CS501',
      name: 'Data Structures & Algorithms',
      course: 'B.Tech',
      department: 'Computer Science & Engineering (CSE)',
      year: '3rd Year',
      semester: 'Semester 5',
      color: '#4f46e5', // indigo
      defaultTeacher: 'Dr. Arvind Sharma',
      defaultRoom: 'Lab 402',
      credits: 4,
      description: 'Advanced trees, graphs, dynamic programming, and complexity analysis.',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: 'sub-btech-2',
      code: 'CS502',
      name: 'Operating Systems',
      course: 'B.Tech',
      department: 'Computer Science & Engineering (CSE)',
      year: '3rd Year',
      semester: 'Semester 5',
      color: '#059669', // emerald
      defaultTeacher: 'Prof. Meera Nair',
      defaultRoom: 'Hall B-12',
      credits: 4,
      description: 'Processes, threads, CPU scheduling, synchronization, and virtual memory.',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: 'sub-btech-3',
      code: 'CS503',
      name: 'Database Management Systems',
      course: 'B.Tech',
      department: 'Computer Science & Engineering (CSE)',
      year: '3rd Year',
      semester: 'Semester 5',
      color: '#0284c7', // sky
      defaultTeacher: 'Dr. Rajesh Roy',
      defaultRoom: 'Room 205',
      credits: 3,
      description: 'Relational algebra, SQL, normalization, transaction processing, and ACID properties.',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: 'sub-btech-4',
      code: 'CS504',
      name: 'Machine Learning Lab',
      course: 'B.Tech',
      department: 'Artificial Intelligence & Machine Learning (AI/ML)',
      year: '3rd Year',
      semester: 'Semester 5',
      color: '#d97706', // amber
      defaultTeacher: 'Prof. Sneha Paul',
      defaultRoom: 'AI Research Lab',
      credits: 2,
      description: 'Hands-on regression, classification, clustering, and neural networks in Python.',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: 'sub-btech-5',
      code: 'CS505',
      name: 'Computer Networks',
      course: 'B.Tech',
      department: 'Computer Science & Engineering (CSE)',
      year: '3rd Year',
      semester: 'Semester 5',
      color: '#7c3aed', // purple
      defaultTeacher: 'Dr. Vivek Verma',
      defaultRoom: 'Room 310',
      credits: 3,
      description: 'OSI & TCP/IP stack, socket programming, routing protocols, and transport layer.',
      createdAt: now,
      updatedAt: now,
    },
    // Diploma CST Subjects
    {
      id: 'sub-dip-1',
      code: 'CST301',
      name: 'C Programming & Data Structures',
      course: 'Diploma',
      department: 'Computer Science & Technology / CST',
      year: '2nd Year',
      semester: 'Semester 3',
      color: '#0d9488', // teal
      defaultTeacher: 'Prof. Ananya Sen',
      defaultRoom: 'Diploma Lab 1',
      credits: 4,
      description: 'Pointers, structures, dynamic allocation, stacks, queues, and linked lists in C.',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: 'sub-dip-2',
      code: 'CST302',
      name: 'Digital Electronics Lab',
      course: 'Diploma',
      department: 'Computer Science & Technology / CST',
      year: '2nd Year',
      semester: 'Semester 3',
      color: '#e11d48', // rose
      defaultTeacher: 'Prof. K. R. Das',
      defaultRoom: 'Hardware Lab',
      credits: 3,
      description: 'Logic gates, multiplexers, flip-flops, counters, and Boolean minimization.',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: 'sub-dip-3',
      code: 'CST303',
      name: 'Microprocessor & Interfacing',
      course: 'Diploma',
      department: 'Computer Science & Technology / CST',
      year: '2nd Year',
      semester: 'Semester 3',
      color: '#ea580c', // orange
      defaultTeacher: 'Prof. Sunil Joshi',
      defaultRoom: 'Embedded Systems Lab',
      credits: 4,
      description: '8085 architecture, assembly language programming, interrupt handling, and I/O interfacing.',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: 'sub-dip-4',
      code: 'CST304',
      name: 'Web Technology Tutorial',
      course: 'Diploma',
      department: 'Computer Science & Technology / CST',
      year: '2nd Year',
      semester: 'Semester 3',
      color: '#475569', // slate
      defaultTeacher: 'Prof. Priya Dey',
      defaultRoom: 'Room D-104',
      credits: 2,
      description: 'HTML5, CSS3, responsive layouts, and basic JavaScript client-side scripting.',
      createdAt: now,
      updatedAt: now,
    },
  ];
}

// Generate demo sessions linked to dynamic dates
export function getInitialDemoSessions(subjects: Subject[]): Session[] {
  const today = new Date();
  const getDayOffset = (offset: number) => {
    const d = new Date(today);
    d.setDate(today.getDate() + offset);
    return formatDate(d);
  };

  const now = new Date().toISOString();
  const subMap = new Map(subjects.map((s) => [s.id, s]));

  return [
    // Calculus & Linear Algebra (From user design reference)
    {
      id: 'sess-math-1',
      title: 'Calculus & Linear Algebra',
      subjectId: 'sub-btech-math',
      subjectName: subMap.get('sub-btech-math')?.name || 'Mathematics',
      subjectCode: 'BS101',
      course: 'B.Tech',
      department: 'Computer Science & Engineering (CSE)',
      year: '1st Year',
      semester: 'Semester 1',
      date: '2026-10-01',
      startTime: '10:00',
      endTime: '11:00',
      sessionType: 'Lecture',
      teacher: 'Dr. S. K. Rao',
      room: 'Room 101',
      notes: 'Differential calculus & matrices review',
      status: 'Scheduled',
      color: '#4f46e5',
      createdAt: now,
      updatedAt: now,
    },
    // C Programming Hands-on Lab (From user design reference)
    {
      id: 'sess-cprog-1',
      title: 'C Programming Hands-on Lab',
      subjectId: 'sub-btech-cprog',
      subjectName: subMap.get('sub-btech-cprog')?.name || 'Programming in C',
      subjectCode: 'CS102',
      course: 'B.Tech',
      department: 'Computer Science & Engineering (CSE)',
      year: '1st Year',
      semester: 'Semester 1',
      date: '2026-10-01',
      startTime: '12:00',
      endTime: '13:30',
      sessionType: 'Lab',
      teacher: 'Prof. Ananya Sen',
      room: 'Computing Lab 2',
      notes: 'Pointers, dynamic memory allocation and structs',
      status: 'Scheduled',
      color: '#0284c7',
      createdAt: now,
      updatedAt: now,
    },
    // Today's B.Tech Sessions
    {
      id: 'sess-1',
      title: 'Advanced Dynamic Programming & Graph Theory',
      subjectId: 'sub-btech-1',
      subjectName: subMap.get('sub-btech-1')?.name || 'Data Structures & Algorithms',
      subjectCode: 'CS501',
      course: 'B.Tech',
      department: 'Computer Science & Engineering (CSE)',
      year: '3rd Year',
      semester: 'Semester 5',
      date: getDayOffset(0),
      startTime: '09:30',
      endTime: '11:00',
      sessionType: 'Lecture',
      teacher: 'Dr. Arvind Sharma',
      room: 'Lab 402',
      notes: 'Review Bellman-Ford and Dijkstra shortest path implementations before class.',
      status: 'Scheduled',
      color: '#4f46e5',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: 'sess-2',
      title: 'Virtual Memory & Page Replacement Algorithms',
      subjectId: 'sub-btech-2',
      subjectName: subMap.get('sub-btech-2')?.name || 'Operating Systems',
      subjectCode: 'CS502',
      course: 'B.Tech',
      department: 'Computer Science & Engineering (CSE)',
      year: '3rd Year',
      semester: 'Semester 5',
      date: getDayOffset(0),
      startTime: '11:30',
      endTime: '12:45',
      sessionType: 'Lecture',
      teacher: 'Prof. Meera Nair',
      room: 'Hall B-12',
      notes: 'Bring previous quiz solutions. LRU and Optimal page replacement numericals.',
      status: 'Scheduled',
      color: '#059669',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: 'sess-3',
      title: 'SQL Normalization & BCNF Hands-On Lab',
      subjectId: 'sub-btech-3',
      subjectName: subMap.get('sub-btech-3')?.name || 'Database Management Systems',
      subjectCode: 'CS503',
      course: 'B.Tech',
      department: 'Computer Science & Engineering (CSE)',
      year: '3rd Year',
      semester: 'Semester 5',
      date: getDayOffset(0),
      startTime: '14:00',
      endTime: '16:00',
      sessionType: 'Practical',
      teacher: 'Dr. Rajesh Roy',
      room: 'Room 205',
      notes: 'Complete queries 1 through 8 in MySQL workbench.',
      status: 'Scheduled',
      color: '#0284c7',
      createdAt: now,
      updatedAt: now,
    },

    // Tomorrow's B.Tech Sessions
    {
      id: 'sess-4',
      title: 'PyTorch Deep Learning Model Training',
      subjectId: 'sub-btech-4',
      subjectName: subMap.get('sub-btech-4')?.name || 'Machine Learning Lab',
      subjectCode: 'CS504',
      course: 'B.Tech',
      department: 'Artificial Intelligence & Machine Learning (AI/ML)',
      year: '3rd Year',
      semester: 'Semester 5',
      date: getDayOffset(1),
      startTime: '10:00',
      endTime: '12:30',
      sessionType: 'Lab',
      teacher: 'Prof. Sneha Paul',
      room: 'AI Research Lab',
      notes: 'Submit lab record 3 by 5 PM. Dataset: CIFAR-10 classification.',
      status: 'Scheduled',
      color: '#d97706',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: 'sess-5',
      title: 'TCP Flow Control & Congestion Window',
      subjectId: 'sub-btech-5',
      subjectName: subMap.get('sub-btech-5')?.name || 'Computer Networks',
      subjectCode: 'CS505',
      course: 'B.Tech',
      department: 'Computer Science & Engineering (CSE)',
      year: '3rd Year',
      semester: 'Semester 5',
      date: getDayOffset(1),
      startTime: '14:00',
      endTime: '15:30',
      sessionType: 'Lecture',
      teacher: 'Dr. Vivek Verma',
      room: 'Room 310',
      notes: 'Wireshark packet capture demo scheduled.',
      status: 'Scheduled',
      color: '#7c3aed',
      createdAt: now,
      updatedAt: now,
    },

    // Today's Diploma Session
    {
      id: 'sess-6',
      title: 'Pointers & Dynamic Memory in C Programming',
      subjectId: 'sub-dip-1',
      subjectName: subMap.get('sub-dip-1')?.name || 'C Programming & Data Structures',
      subjectCode: 'CST301',
      course: 'Diploma',
      department: 'Computer Science & Technology / CST',
      year: '2nd Year',
      semester: 'Semester 3',
      date: getDayOffset(0),
      startTime: '10:00',
      endTime: '11:30',
      sessionType: 'Lecture',
      teacher: 'Prof. Ananya Sen',
      room: 'Diploma Lab 1',
      notes: 'Demonstration of malloc, calloc, realloc and free functions.',
      status: 'Scheduled',
      color: '#0d9488',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: 'sess-7',
      title: 'Flip-Flops & Counter Circuit Wiring',
      subjectId: 'sub-dip-2',
      subjectName: subMap.get('sub-dip-2')?.name || 'Digital Electronics Lab',
      subjectCode: 'CST302',
      course: 'Diploma',
      department: 'Computer Science & Technology / CST',
      year: '2nd Year',
      semester: 'Semester 3',
      date: getDayOffset(0),
      startTime: '12:30',
      endTime: '14:30',
      sessionType: 'Practical',
      teacher: 'Prof. K. R. Das',
      room: 'Hardware Lab',
      notes: 'Verify truth tables for JK Master-Slave flip-flop with IC 7476.',
      status: 'Scheduled',
      color: '#e11d48',
      createdAt: now,
      updatedAt: now,
    },

    // Tomorrow's Diploma Sessions
    {
      id: 'sess-8',
      title: '8085 Assembly Language Instructions Practice',
      subjectId: 'sub-dip-3',
      subjectName: subMap.get('sub-dip-3')?.name || 'Microprocessor & Interfacing',
      subjectCode: 'CST303',
      course: 'Diploma',
      department: 'Computer Science & Technology / CST',
      year: '2nd Year',
      semester: 'Semester 3',
      date: getDayOffset(1),
      startTime: '09:00',
      endTime: '10:30',
      sessionType: 'Lecture',
      teacher: 'Prof. Sunil Joshi',
      room: 'Embedded Systems Lab',
      notes: 'Data transfer and arithmetic instruction set exercises.',
      status: 'Scheduled',
      color: '#ea580c',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: 'sess-9',
      title: 'CSS Grid & Flexbox Practice Assignment',
      subjectId: 'sub-dip-4',
      subjectName: subMap.get('sub-dip-4')?.name || 'Web Technology Tutorial',
      subjectCode: 'CST304',
      course: 'Diploma',
      department: 'Computer Science & Technology / CST',
      year: '2nd Year',
      semester: 'Semester 3',
      date: getDayOffset(1),
      startTime: '11:00',
      endTime: '12:30',
      sessionType: 'Tutorial',
      teacher: 'Prof. Priya Dey',
      room: 'Room D-104',
      notes: 'Build a two-column responsive portfolio layout.',
      status: 'Scheduled',
      color: '#475569',
      createdAt: now,
      updatedAt: now,
    },

    // Upcoming Days sessions
    {
      id: 'sess-10',
      title: 'Midterm Examination Revision: Algorithms & Trees',
      subjectId: 'sub-btech-1',
      subjectName: subMap.get('sub-btech-1')?.name || 'Data Structures & Algorithms',
      subjectCode: 'CS501',
      course: 'B.Tech',
      department: 'Computer Science & Engineering (CSE)',
      year: '3rd Year',
      semester: 'Semester 5',
      date: getDayOffset(2),
      startTime: '10:00',
      endTime: '12:00',
      sessionType: 'Revision',
      teacher: 'Dr. Arvind Sharma',
      room: 'Lab 402',
      notes: 'Group discussion and mock problem solving on AVL and Red-Black trees.',
      status: 'Scheduled',
      color: '#4f46e5',
      createdAt: now,
      updatedAt: now,
    },
    {
      id: 'sess-11',
      title: 'Semester Project Architecture Discussion',
      subjectId: 'sub-btech-3',
      subjectName: subMap.get('sub-btech-3')?.name || 'Database Management Systems',
      subjectCode: 'CS503',
      course: 'B.Tech',
      department: 'Computer Science & Engineering (CSE)',
      year: '3rd Year',
      semester: 'Semester 5',
      date: getDayOffset(3),
      startTime: '14:30',
      endTime: '16:00',
      sessionType: 'Project',
      teacher: 'Dr. Rajesh Roy',
      room: 'Room 205',
      notes: 'Finalize ER diagram and table relationships for team project.',
      status: 'Scheduled',
      color: '#0284c7',
      createdAt: now,
      updatedAt: now,
    },
  ];
}

export function getDefaultPreferences(): UserPreferences {
  return {
    defaultCourse: 'B.Tech',
    defaultDepartment: 'Computer Science & Engineering (CSE)',
    defaultYear: '3rd Year',
    defaultSemester: 'Semester 5',
    defaultSessionDuration: 60,
    defaultSessionType: 'Lecture',
    calendarStartHour: 8,
    calendarEndHour: 20,
  };
}

class StorageService {
  private subjectsCache: Subject[] | null = null;
  private sessionsCache: Session[] | null = null;
  private prefsCache: UserPreferences | null = null;

  constructor() {
    this.init();
  }

  private init() {
    // If subjects not in localStorage, seed with demo subjects
    if (!localStorage.getItem(SUBJECTS_KEY)) {
      const demoSubjects = getInitialDemoSubjects();
      localStorage.setItem(SUBJECTS_KEY, JSON.stringify(demoSubjects));
      this.subjectsCache = demoSubjects;
    }

    // If sessions not in localStorage, seed with demo sessions
    if (!localStorage.getItem(SESSIONS_KEY)) {
      const subjects = this.getSubjects();
      const demoSessions = getInitialDemoSessions(subjects);
      localStorage.setItem(SESSIONS_KEY, JSON.stringify(demoSessions));
      this.sessionsCache = demoSessions;
    }

    // Preferences
    if (!localStorage.getItem(PREFS_KEY)) {
      const defaultPrefs = getDefaultPreferences();
      localStorage.setItem(PREFS_KEY, JSON.stringify(defaultPrefs));
      this.prefsCache = defaultPrefs;
    }
  }

  // Subjects
  getSubjects(): Subject[] {
    try {
      const data = localStorage.getItem(SUBJECTS_KEY);
      if (data) {
        this.subjectsCache = JSON.parse(data);
        return this.subjectsCache || [];
      }
    } catch (e) {
      console.error('Failed to parse subjects from localStorage', e);
    }
    const fallback = getInitialDemoSubjects();
    this.subjectsCache = fallback;
    return fallback;
  }

  saveSubject(subject: Omit<Subject, 'id' | 'createdAt' | 'updatedAt'>): Subject {
    const subjects = this.getSubjects();
    const now = new Date().toISOString();
    const newSubject: Subject = {
      ...subject,
      id: `sub-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      createdAt: now,
      updatedAt: now,
    };
    subjects.push(newSubject);
    localStorage.setItem(SUBJECTS_KEY, JSON.stringify(subjects));
    this.subjectsCache = subjects;
    return newSubject;
  }

  updateSubject(subject: Subject): Subject {
    const subjects = this.getSubjects();
    const index = subjects.findIndex((s) => s.id === subject.id);
    const updated: Subject = {
      ...subject,
      updatedAt: new Date().toISOString(),
    };
    if (index !== -1) {
      subjects[index] = updated;
    } else {
      subjects.push(updated);
    }
    localStorage.setItem(SUBJECTS_KEY, JSON.stringify(subjects));
    this.subjectsCache = subjects;

    // Also update any sessions that use this subject's name/code/color
    const sessions = this.getSessions();
    let sessionsChanged = false;
    const updatedSessions = sessions.map((sess) => {
      if (sess.subjectId === subject.id) {
        sessionsChanged = true;
        return {
          ...sess,
          subjectName: subject.name,
          subjectCode: subject.code,
          color: subject.color,
          updatedAt: new Date().toISOString(),
        };
      }
      return sess;
    });
    if (sessionsChanged) {
      localStorage.setItem(SESSIONS_KEY, JSON.stringify(updatedSessions));
      this.sessionsCache = updatedSessions;
    }

    return updated;
  }

  deleteSubject(id: string, deleteRelatedSessions = false): void {
    const subjects = this.getSubjects().filter((s) => s.id !== id);
    localStorage.setItem(SUBJECTS_KEY, JSON.stringify(subjects));
    this.subjectsCache = subjects;

    if (deleteRelatedSessions) {
      const sessions = this.getSessions().filter((sess) => sess.subjectId !== id);
      localStorage.setItem(SESSIONS_KEY, JSON.stringify(sessions));
      this.sessionsCache = sessions;
    }
  }

  // Sessions
  getSessions(): Session[] {
    try {
      const data = localStorage.getItem(SESSIONS_KEY);
      if (data) {
        this.sessionsCache = JSON.parse(data);
        return this.sessionsCache || [];
      }
    } catch (e) {
      console.error('Failed to parse sessions from localStorage', e);
    }
    const fallback = getInitialDemoSessions(this.getSubjects());
    this.sessionsCache = fallback;
    return fallback;
  }

  saveSession(session: Omit<Session, 'id' | 'createdAt' | 'updatedAt'>): Session {
    const sessions = this.getSessions();
    const now = new Date().toISOString();
    const newSession: Session = {
      ...session,
      id: `sess-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      createdAt: now,
      updatedAt: now,
    };
    sessions.push(newSession);
    localStorage.setItem(SESSIONS_KEY, JSON.stringify(sessions));
    this.sessionsCache = sessions;
    return newSession;
  }

  updateSession(session: Session): Session {
    const sessions = this.getSessions();
    const index = sessions.findIndex((s) => s.id === session.id);
    const updated: Session = {
      ...session,
      updatedAt: new Date().toISOString(),
    };
    if (index !== -1) {
      // Clean replace of only this session - preserving all other sessions independently
      sessions[index] = updated;
    } else {
      sessions.push(updated);
    }
    localStorage.setItem(SESSIONS_KEY, JSON.stringify(sessions));
    this.sessionsCache = sessions;
    return updated;
  }

  // Dedicated single-session time change method - Requirement #5
  updateSessionTime(
    id: string,
    updates: {
      date?: string;
      startTime?: string;
      endTime?: string;
      status?: Session['status'];
    }
  ): Session | null {
    const sessions = this.getSessions();
    const index = sessions.findIndex((s) => s.id === id);
    if (index === -1) return null;

    const current = sessions[index];
    const updated: Session = {
      ...current,
      ...(updates.date ? { date: updates.date } : {}),
      ...(updates.startTime ? { startTime: updates.startTime } : {}),
      ...(updates.endTime ? { endTime: updates.endTime } : {}),
      ...(updates.status ? { status: updates.status } : {}),
      updatedAt: new Date().toISOString(),
    };

    // Only update this exact session without touching any other sessions!
    sessions[index] = updated;
    localStorage.setItem(SESSIONS_KEY, JSON.stringify(sessions));
    this.sessionsCache = sessions;
    return updated;
  }

  duplicateSession(id: string, newDate?: string, newStartTime?: string, newEndTime?: string): Session | null {
    const sessions = this.getSessions();
    const target = sessions.find((s) => s.id === id);
    if (!target) return null;

    const now = new Date().toISOString();
    const duplicate: Session = {
      ...target,
      id: `sess-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      title: `${target.title} (Copy)`,
      date: newDate || target.date,
      startTime: newStartTime || target.startTime,
      endTime: newEndTime || target.endTime,
      status: 'Scheduled',
      createdAt: now,
      updatedAt: now,
    };

    sessions.push(duplicate);
    localStorage.setItem(SESSIONS_KEY, JSON.stringify(sessions));
    this.sessionsCache = sessions;
    return duplicate;
  }

  deleteSession(id: string): void {
    const sessions = this.getSessions().filter((s) => s.id !== id);
    localStorage.setItem(SESSIONS_KEY, JSON.stringify(sessions));
    this.sessionsCache = sessions;
  }

  // Preferences
  getPreferences(): UserPreferences {
    try {
      const data = localStorage.getItem(PREFS_KEY);
      if (data) {
        this.prefsCache = JSON.parse(data);
        return this.prefsCache || getDefaultPreferences();
      }
    } catch (e) {
      console.error('Failed to parse preferences from localStorage', e);
    }
    const fallback = getDefaultPreferences();
    this.prefsCache = fallback;
    return fallback;
  }

  savePreferences(prefs: UserPreferences): void {
    localStorage.setItem(PREFS_KEY, JSON.stringify(prefs));
    this.prefsCache = prefs;
  }

  // Import / Export
  exportData(): string {
    const payload = {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      appName: 'StudySprint',
      subjects: this.getSubjects(),
      sessions: this.getSessions(),
      preferences: this.getPreferences(),
    };
    return JSON.stringify(payload, null, 2);
  }

  importData(jsonString: string): { success: boolean; message: string; count?: { subjects: number; sessions: number } } {
    try {
      const parsed = JSON.parse(jsonString);
      if (!parsed || !Array.isArray(parsed.subjects) || !Array.isArray(parsed.sessions)) {
        return { success: false, message: 'Invalid data format. File must contain subjects and sessions arrays.' };
      }

      localStorage.setItem(SUBJECTS_KEY, JSON.stringify(parsed.subjects));
      localStorage.setItem(SESSIONS_KEY, JSON.stringify(parsed.sessions));
      if (parsed.preferences) {
        localStorage.setItem(PREFS_KEY, JSON.stringify(parsed.preferences));
      }

      this.subjectsCache = parsed.subjects;
      this.sessionsCache = parsed.sessions;
      if (parsed.preferences) this.prefsCache = parsed.preferences;

      return {
        success: true,
        message: 'Data successfully restored!',
        count: { subjects: parsed.subjects.length, sessions: parsed.sessions.length },
      };
    } catch (err: any) {
      return { success: false, message: `Failed to parse JSON: ${err.message}` };
    }
  }

  resetToDemoData(): void {
    const demoSubjects = getInitialDemoSubjects();
    const demoSessions = getInitialDemoSessions(demoSubjects);
    const demoPrefs = getDefaultPreferences();

    localStorage.setItem(SUBJECTS_KEY, JSON.stringify(demoSubjects));
    localStorage.setItem(SESSIONS_KEY, JSON.stringify(demoSessions));
    localStorage.setItem(PREFS_KEY, JSON.stringify(demoPrefs));

    this.subjectsCache = demoSubjects;
    this.sessionsCache = demoSessions;
    this.prefsCache = demoPrefs;
  }
}

export const storageService = new StorageService();
