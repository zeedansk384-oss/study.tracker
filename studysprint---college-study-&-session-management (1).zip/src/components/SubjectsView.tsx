import React from 'react';
import {
  BookOpen,
  Plus,
  Edit3,
  Trash2,
  Calendar,
  Layers,
  User,
  MapPin,
  Clock,
} from 'lucide-react';
import { Subject, Session, CourseType } from '../types/academic';

interface SubjectsViewProps {
  subjects: Subject[];
  sessions: Session[];
  onOpenAddSubject: () => void;
  onEditSubject: (subject: Subject) => void;
  onDeleteSubject: (subject: Subject) => void;
  onQuickAddSessionForSubject: (subject: Subject) => void;
}

export const SubjectsView: React.FC<SubjectsViewProps> = ({
  subjects,
  sessions,
  onOpenAddSubject,
  onEditSubject,
  onDeleteSubject,
  onQuickAddSessionForSubject,
}) => {
  // Group subjects by Course (B.Tech, Diploma, Other)
  const btechSubjects = subjects.filter((s) => s.course === 'B.Tech');
  const diplomaSubjects = subjects.filter((s) => s.course === 'Diploma');
  const otherSubjects = subjects.filter((s) => s.course !== 'B.Tech' && s.course !== 'Diploma');

  const renderSubjectCard = (sub: Subject) => {
    const subSessions = sessions.filter((s) => s.subjectId === sub.id);

    return (
      <div
        key={sub.id}
        className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-5 shadow-xs hover:border-slate-300 dark:hover:border-slate-700 transition-all flex flex-col justify-between"
      >
        <div className="space-y-3">
          {/* Top header: Code & Color Indicator */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span
                className="w-3 h-3 rounded-full shrink-0"
                style={{ backgroundColor: sub.color }}
              />
              <span className="text-xs font-mono font-bold text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-md">
                {sub.code || 'NO-CODE'}
              </span>
            </div>

            <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              {sub.credits ? `${sub.credits} Credits` : 'Elective'}
            </span>
          </div>

          {/* Subject Name */}
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white leading-snug">{sub.name}</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">
              {sub.description || 'No description added.'}
            </p>
          </div>

          {/* Academic Info */}
          <div className="text-xs text-slate-600 dark:text-slate-300 space-y-1 bg-slate-50 dark:bg-slate-800/60 p-3 rounded-xl border border-slate-100 dark:border-slate-800">
            <div className="font-semibold text-slate-800 dark:text-slate-200 truncate">{sub.department}</div>
            <div className="flex items-center gap-2 text-slate-500 dark:text-slate-400 text-[11px]">
              <span>{sub.year}</span>
              <span>·</span>
              <span>{sub.semester}</span>
            </div>
            {sub.defaultTeacher && (
              <div className="flex items-center gap-1.5 pt-1 text-[11px] text-slate-600 dark:text-slate-300">
                <User className="w-3 h-3 text-slate-400" />
                <span className="truncate">{sub.defaultTeacher}</span>
              </div>
            )}
            {sub.defaultRoom && (
              <div className="flex items-center gap-1.5 text-[11px] text-slate-600 dark:text-slate-300">
                <MapPin className="w-3 h-3 text-slate-400" />
                <span className="truncate">{sub.defaultRoom}</span>
              </div>
            )}
          </div>
        </div>

        {/* Bottom stats & actions */}
        <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
            <Calendar className="w-3.5 h-3.5 text-slate-400" />
            <span className="font-mono tabular-nums font-semibold text-slate-700 dark:text-slate-300">
              {subSessions.length}
            </span>
            <span>sessions</span>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => onQuickAddSessionForSubject(sub)}
              className="px-2.5 py-1 text-xs font-semibold text-white bg-sky-500 hover:bg-sky-600 rounded-lg shadow-2xs transition-colors cursor-pointer"
              title="Schedule a session for this subject"
            >
              + Session
            </button>
            <button
              type="button"
              onClick={() => onEditSubject(sub)}
              className="p-1.5 text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
              title="Edit Subject"
            >
              <Edit3 className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => onDeleteSubject(sub)}
              className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors cursor-pointer"
              title="Delete Subject"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Curriculum & Subjects
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Add, edit, or customize subjects for both B.Tech and Diploma programs. Subjects have no fixed session times.
          </p>
        </div>

        <button
          onClick={onOpenAddSubject}
          type="button"
          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs sm:text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition-all shadow-sm self-start sm:self-center cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>+ Add Subject</span>
        </button>
      </div>

      {/* B.Tech Subjects Section */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wide">
              B.Tech Engineering Subjects
            </h3>
            <span className="text-xs font-mono font-semibold text-indigo-700 dark:text-indigo-300 bg-indigo-50 dark:bg-indigo-950/60 px-2 py-0.5 rounded-full">
              {btechSubjects.length}
            </span>
          </div>
        </div>

        {btechSubjects.length === 0 ? (
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 text-center text-xs text-slate-500 dark:text-slate-400">
            No B.Tech subjects configured. Click &quot;Add Subject&quot; above to create one.
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {btechSubjects.map(renderSubjectCard)}
          </div>
        )}
      </div>

      {/* Diploma Subjects Section */}
      <div className="space-y-3 pt-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wide">
              Diploma Engineering Subjects
            </h3>
            <span className="text-xs font-mono font-semibold text-teal-700 dark:text-teal-300 bg-teal-50 dark:bg-teal-950/60 px-2 py-0.5 rounded-full">
              {diplomaSubjects.length}
            </span>
          </div>
        </div>

        {diplomaSubjects.length === 0 ? (
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 text-center text-xs text-slate-500 dark:text-slate-400">
            No Diploma subjects configured. Click &quot;Add Subject&quot; to add Diploma courses.
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {diplomaSubjects.map(renderSubjectCard)}
          </div>
        )}
      </div>

      {/* Custom / Other Subjects Section */}
      {otherSubjects.length > 0 && (
        <div className="space-y-3 pt-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wide">
                Other Specializations
              </h3>
              <span className="text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-full">
                {otherSubjects.length}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {otherSubjects.map(renderSubjectCard)}
          </div>
        </div>
      )}
    </div>
  );
};
