import React from 'react';
import { Search, X, RotateCcw, Filter } from 'lucide-react';
import { AcademicFilterState, CourseType, Subject } from '../types/academic';
import {
  getDepartmentsForCourse,
  getYearsForCourse,
  getSemestersForCourseAndYear,
  SESSION_TYPES,
} from '../constants/academicData';

interface AcademicFilterBarProps {
  filters: AcademicFilterState;
  onFilterChange: (newFilters: AcademicFilterState) => void;
  subjects: Subject[];
  compact?: boolean;
}

export const AcademicFilterBar: React.FC<AcademicFilterBarProps> = ({
  filters,
  onFilterChange,
  subjects,
  compact = false,
}) => {
  const departments = getDepartmentsForCourse(filters.course as CourseType);
  const years = getYearsForCourse(filters.course as CourseType);
  const semesters = getSemestersForCourseAndYear(
    filters.course as CourseType,
    filters.year !== 'All' ? filters.year : undefined
  );

  const hasActiveFilters =
    filters.course !== 'All' ||
    filters.department !== 'All' ||
    filters.year !== 'All' ||
    filters.semester !== 'All' ||
    filters.subjectId !== 'All' ||
    filters.sessionType !== 'All' ||
    filters.status !== 'All' ||
    Boolean(filters.searchQuery);

  const handleReset = () => {
    onFilterChange({
      course: 'All',
      department: 'All',
      year: 'All',
      semester: 'All',
      subjectId: 'All',
      sessionType: 'All',
      status: 'All',
      searchQuery: '',
    });
  };

  const filteredSubjects = subjects.filter((s) => {
    if (filters.course !== 'All' && s.course !== filters.course) return false;
    if (filters.department !== 'All' && s.department !== filters.department) return false;
    if (filters.year !== 'All' && s.year !== filters.year) return false;
    return true;
  });

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-4 sm:p-5 mb-6 shadow-xs">
      {/* Top row: search & primary course switcher & reset */}
      <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between pb-3.5 border-b border-slate-100 dark:border-slate-800">
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search sessions, subjects, faculty, rooms..."
            value={filters.searchQuery}
            onChange={(e) => onFilterChange({ ...filters, searchQuery: e.target.value })}
            className="w-full pl-10 pr-8 py-2 text-xs sm:text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white dark:focus:bg-slate-800 transition-all"
          />
          {filters.searchQuery && (
            <button
              onClick={() => onFilterChange({ ...filters, searchQuery: '' })}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300"
              title="Clear search"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Right side controls */}
        <div className="flex items-center gap-2">
          {/* Quick Course Buttons */}
          <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-0.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs">
            {(['All', 'B.Tech', 'Diploma'] as const).map((c) => (
              <button
                key={c}
                type="button"
                onClick={() =>
                  onFilterChange({
                    ...filters,
                    course: c,
                    department: 'All',
                    year: 'All',
                    semester: 'All',
                    subjectId: 'All',
                  })
                }
                className={`px-3 py-1 font-semibold rounded-lg transition-all whitespace-nowrap cursor-pointer ${
                  filters.course === c
                    ? 'bg-white dark:bg-slate-700 text-indigo-700 dark:text-indigo-300 shadow-2xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {c}
              </button>
            ))}
          </div>

          {hasActiveFilters && (
            <button
              type="button"
              onClick={handleReset}
              className="inline-flex items-center gap-1 px-3 py-1 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:text-rose-600 dark:hover:text-rose-400 bg-slate-50 dark:bg-slate-800 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl transition-colors border border-slate-200 dark:border-slate-700 whitespace-nowrap cursor-pointer"
              title="Reset all filters"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Reset</span>
            </button>
          )}
        </div>
      </div>

      {/* Bottom row: academic dropdowns */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 pt-3.5">
        {/* Department */}
        <div>
          <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">Department</label>
          <select
            value={filters.department}
            onChange={(e) =>
              onFilterChange({
                ...filters,
                department: e.target.value,
                subjectId: 'All',
              })
            }
            className="w-full text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-2.5 py-2 text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500 truncate"
          >
            <option value="All">All Departments</option>
            {departments.map((d) => (
              <option key={d} value={d}>
                {d}
              </option>
            ))}
          </select>
        </div>

        {/* Year */}
        <div>
          <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">Academic Year</label>
          <select
            value={filters.year}
            onChange={(e) =>
              onFilterChange({
                ...filters,
                year: e.target.value,
                semester: 'All',
                subjectId: 'All',
              })
            }
            className="w-full text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-2.5 py-2 text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500"
          >
            <option value="All">All Years</option>
            {years.map((y) => (
              <option key={y} value={y}>
                {y}
              </option>
            ))}
          </select>
        </div>

        {/* Semester */}
        <div>
          <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">Semester</label>
          <select
            value={filters.semester}
            onChange={(e) => onFilterChange({ ...filters, semester: e.target.value })}
            className="w-full text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-2.5 py-2 text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500"
          >
            <option value="All">All Semesters</option>
            {semesters.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        </div>

        {/* Subject */}
        <div>
          <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">Subject</label>
          <select
            value={filters.subjectId}
            onChange={(e) => onFilterChange({ ...filters, subjectId: e.target.value })}
            className="w-full text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-2.5 py-2 text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500 truncate"
          >
            <option value="All">All Subjects</option>
            {filteredSubjects.map((s) => (
              <option key={s.id} value={s.id}>
                {s.code ? `[${s.code}] ` : ''}{s.name}
              </option>
            ))}
          </select>
        </div>

        {/* Session Type */}
        <div>
          <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">Session Type</label>
          <select
            value={filters.sessionType}
            onChange={(e) => onFilterChange({ ...filters, sessionType: e.target.value })}
            className="w-full text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-2.5 py-2 text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500"
          >
            <option value="All">All Types</option>
            {SESSION_TYPES.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
        </div>

        {/* Status */}
        <div>
          <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">Status</label>
          <select
            value={filters.status}
            onChange={(e) => onFilterChange({ ...filters, status: e.target.value })}
            className="w-full text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-2.5 py-2 text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500"
          >
            <option value="All">All Statuses</option>
            <option value="Scheduled">Scheduled</option>
            <option value="In Progress">In Progress</option>
            <option value="Completed">Completed</option>
            <option value="Cancelled">Cancelled</option>
            <option value="Rescheduled">Rescheduled</option>
          </select>
        </div>
      </div>
    </div>
  );
};
