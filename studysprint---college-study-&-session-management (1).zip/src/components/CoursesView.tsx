import React, { useState } from 'react';
import {
  GraduationCap,
  BookOpen,
  Calendar,
  Plus,
  ArrowRight,
  Sparkles,
  School,
  CheckCircle2,
} from 'lucide-react';
import { Subject, Session, CourseType } from '../types/academic';
import {
  BTECH_DEPARTMENTS,
  DIPLOMA_DEPARTMENTS,
  BTECH_YEARS,
  DIPLOMA_YEARS,
  getSemestersForCourseAndYear,
} from '../constants/academicData';

interface CoursesViewProps {
  subjects: Subject[];
  sessions: Session[];
  onOpenAddSubject: () => void;
  onOpenAddSession: () => void;
  onSelectSubjectFilter: (subId: string) => void;
}

export const CoursesView: React.FC<CoursesViewProps> = ({
  subjects,
  sessions,
  onOpenAddSubject,
  onOpenAddSession,
  onSelectSubjectFilter,
}) => {
  const [selectedCourse, setSelectedCourse] = useState<CourseType>('B.Tech');
  const [selectedDept, setSelectedDept] = useState<string>(
    selectedCourse === 'B.Tech' ? BTECH_DEPARTMENTS[0] : DIPLOMA_DEPARTMENTS[0]
  );
  const [selectedYear, setSelectedYear] = useState<string>('1st Year');

  const departments = selectedCourse === 'B.Tech' ? BTECH_DEPARTMENTS : DIPLOMA_DEPARTMENTS;
  const years = selectedCourse === 'B.Tech' ? BTECH_YEARS : DIPLOMA_YEARS;
  const semesters = getSemestersForCourseAndYear(selectedCourse, selectedYear);

  // Filter subjects for the active selection
  const activeSubjects = subjects.filter(
    (s) =>
      s.course === selectedCourse &&
      (s.department === selectedDept || s.department.includes(selectedDept.slice(0, 10))) &&
      s.year === selectedYear
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Academic Courses & Curricula
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Browse degree programs, departments, year-by-year syllabi, and scheduled sessions for B.Tech & Diploma.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenAddSubject}
            type="button"
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs sm:text-sm font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-50 border border-slate-200 dark:border-slate-700 rounded-xl transition-all shadow-2xs cursor-pointer"
          >
            <BookOpen className="w-4 h-4 text-indigo-600" />
            <span>+ Add Subject</span>
          </button>
          <button
            onClick={onOpenAddSession}
            type="button"
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs sm:text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition-all shadow-sm cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>+ Add Session</span>
          </button>
        </div>
      </div>

      {/* Program Selector Tabs */}
      <div className="flex items-center gap-3 border-b border-slate-200 dark:border-slate-800 pb-2">
        {(['B.Tech', 'Diploma'] as const).map((c) => {
          const isSelected = selectedCourse === c;
          return (
            <button
              key={c}
              type="button"
              onClick={() => {
                setSelectedCourse(c);
                const deps = c === 'B.Tech' ? BTECH_DEPARTMENTS : DIPLOMA_DEPARTMENTS;
                setSelectedDept(deps[0]);
                setSelectedYear('1st Year');
              }}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-sm transition-all cursor-pointer ${
                isSelected
                  ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-sm'
                  : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700'
              }`}
            >
              <GraduationCap className="w-4 h-4" />
              <span>{c === 'B.Tech' ? 'Bachelor of Technology (B.Tech)' : 'Polytechnic Diploma'}</span>
            </button>
          );
        })}
      </div>

      {/* Department & Year Switchers */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Left: Departments list */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-4 shadow-xs space-y-2">
          <h3 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider px-2">
            Departments ({departments.length})
          </h3>
          <div className="space-y-1 max-h-[460px] overflow-y-auto pr-1">
            {departments.map((d) => {
              const isSelected = selectedDept === d;
              return (
                <button
                  key={d}
                  type="button"
                  onClick={() => setSelectedDept(d)}
                  className={`w-full text-left px-3 py-2 rounded-xl text-xs font-semibold transition-all truncate cursor-pointer ${
                    isSelected
                      ? 'bg-indigo-50 dark:bg-indigo-950/50 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800'
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white'
                  }`}
                  title={d}
                >
                  {d}
                </button>
              );
            })}
          </div>
        </div>

        {/* Right: Year breakdown & Subjects */}
        <div className="lg:col-span-3 space-y-4">
          {/* Year selector pills */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-3 shadow-xs flex items-center gap-2">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 px-2">
              Select Year:
            </span>
            {years.map((y) => {
              const isSelected = selectedYear === y;
              return (
                <button
                  key={y}
                  type="button"
                  onClick={() => setSelectedYear(y)}
                  className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-indigo-600 text-white shadow-2xs'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                  }`}
                >
                  {y}
                </button>
              );
            })}
          </div>

          {/* Department Overview Banner */}
          <div className="bg-gradient-to-r from-slate-900 to-indigo-950 text-white rounded-2xl p-5 shadow-sm space-y-2">
            <div className="text-xs font-semibold text-indigo-300 uppercase tracking-wider">
              {selectedCourse} · {selectedYear}
            </div>
            <h2 className="text-lg sm:text-xl font-bold">{selectedDept}</h2>
            <div className="flex flex-wrap items-center gap-4 text-xs text-slate-300 pt-1">
              <span>Semesters: {semesters.join(' & ')}</span>
              <span>·</span>
              <span>{activeSubjects.length} Registered Subjects</span>
            </div>
          </div>

          {/* Enrolled Subjects under this selection */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Curriculum Subjects for {selectedYear}
              </h3>
              <button
                type="button"
                onClick={onOpenAddSubject}
                className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
              >
                + Add Subject for this Department
              </button>
            </div>

            {activeSubjects.length === 0 ? (
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-8 text-center space-y-3">
                <BookOpen className="w-8 h-8 text-slate-300 dark:text-slate-600 mx-auto" />
                <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
                  No subjects registered yet for {selectedDept} ({selectedYear}).
                </p>
                <button
                  type="button"
                  onClick={onOpenAddSubject}
                  className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-2xs cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Register Subject</span>
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {activeSubjects.map((sub) => {
                  const subSessions = sessions.filter((s) => s.subjectId === sub.id);
                  return (
                    <div
                      key={sub.id}
                      className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-4 shadow-xs hover:border-slate-300 space-y-2.5 transition-all"
                    >
                      <div className="flex items-center justify-between">
                        <span
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: sub.color }}
                        />
                        <span className="text-xs font-mono font-bold text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded">
                          {sub.code || 'NO-CODE'}
                        </span>
                      </div>

                      <div>
                        <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                          {sub.name}
                        </h4>
                        <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 mt-0.5">
                          {sub.description || 'No syllabus description provided.'}
                        </p>
                      </div>

                      <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                        <span>{subSessions.length} active sessions</span>
                        <button
                          type="button"
                          onClick={() => onSelectSubjectFilter(sub.id)}
                          className="font-semibold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1 cursor-pointer"
                        >
                          <span>View Sessions</span>
                          <ArrowRight className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
