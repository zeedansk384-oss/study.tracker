import React, { useState, useEffect } from 'react';
import { BookOpen, X, Check, AlertCircle } from 'lucide-react';
import { Subject, CourseType } from '../types/academic';
import {
  getDepartmentsForCourse,
  getYearsForCourse,
  getSemestersForCourseAndYear,
  SUBJECT_COLORS,
} from '../constants/academicData';

interface SubjectModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (subject: Omit<Subject, 'id' | 'createdAt' | 'updatedAt'> | Subject) => void;
  initialSubject?: Subject | null;
  defaultCourse?: CourseType;
}

export const SubjectModal: React.FC<SubjectModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialSubject,
  defaultCourse = 'B.Tech',
}) => {
  if (!isOpen) return null;

  const isEditing = Boolean(initialSubject);

  const [name, setName] = useState(initialSubject?.name || '');
  const [code, setCode] = useState(initialSubject?.code || '');
  const [course, setCourse] = useState<CourseType>(initialSubject?.course || defaultCourse);
  const [department, setDepartment] = useState(
    initialSubject?.department || getDepartmentsForCourse(initialSubject?.course || defaultCourse)[0]
  );
  const [customDepartment, setCustomDepartment] = useState(
    initialSubject?.department && !getDepartmentsForCourse(initialSubject?.course || defaultCourse).includes(initialSubject.department)
      ? initialSubject.department
      : ''
  );
  const [year, setYear] = useState(
    initialSubject?.year || getYearsForCourse(initialSubject?.course || defaultCourse)[0]
  );
  const [semester, setSemester] = useState(
    initialSubject?.semester ||
      getSemestersForCourseAndYear(
        initialSubject?.course || defaultCourse,
        initialSubject?.year || getYearsForCourse(initialSubject?.course || defaultCourse)[0]
      )[0]
  );
  const [color, setColor] = useState(initialSubject?.color || SUBJECT_COLORS[0].value);
  const [defaultTeacher, setDefaultTeacher] = useState(initialSubject?.defaultTeacher || '');
  const [defaultRoom, setDefaultRoom] = useState(initialSubject?.defaultRoom || '');
  const [credits, setCredits] = useState<number | ''>(
    initialSubject?.credits !== undefined ? initialSubject.credits : 3
  );
  const [description, setDescription] = useState(initialSubject?.description || '');
  const [error, setError] = useState<string | null>(null);

  // Synchronize when course changes
  const handleCourseChange = (newCourse: CourseType) => {
    setCourse(newCourse);
    const deps = getDepartmentsForCourse(newCourse);
    setDepartment(deps[0]);
    setCustomDepartment('');
    const yrs = getYearsForCourse(newCourse);
    setYear(yrs[0]);
    const sems = getSemestersForCourseAndYear(newCourse, yrs[0]);
    setSemester(sems[0]);
  };

  // Synchronize when year changes
  const handleYearChange = (newYear: string) => {
    setYear(newYear);
    const sems = getSemestersForCourseAndYear(course, newYear);
    if (!sems.includes(semester)) {
      setSemester(sems[0]);
    }
  };

  const departments = getDepartmentsForCourse(course);
  const years = getYearsForCourse(course);
  const semesters = getSemestersForCourseAndYear(course, year);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Subject name is required');
      return;
    }

    const finalDepartment = department === 'Other' ? (customDepartment.trim() || 'General Studies') : department;

    const payload: any = {
      name: name.trim(),
      code: code.trim(),
      course,
      department: finalDepartment,
      year,
      semester,
      color,
      defaultTeacher: defaultTeacher.trim() || undefined,
      defaultRoom: defaultRoom.trim() || undefined,
      credits: credits === '' ? undefined : Number(credits),
      description: description.trim() || undefined,
    };

    if (isEditing && initialSubject) {
      onSave({
        ...initialSubject,
        ...payload,
      });
    } else {
      onSave(payload);
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div
        className="bg-white dark:bg-slate-900 rounded-2xl max-w-xl w-full shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden transform transition-all my-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-100 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-400 flex items-center justify-center">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                {isEditing ? 'Edit Subject' : 'Add New Subject'}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">Configure curriculum details and defaults</p>
            </div>
          </div>
          <button
            onClick={onClose}
            type="button"
            className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          {error && (
            <div className="flex items-center gap-2 p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-700">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Subject Name and Code */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Subject Name <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                placeholder="e.g. Data Structures & Algorithms"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Subject Code
              </label>
              <input
                type="text"
                placeholder="e.g. CS501"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                className="w-full px-3 py-2 text-sm font-mono bg-white border border-slate-300 rounded-lg text-slate-900 uppercase focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          {/* Academic Track: Course, Department */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Course */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Course</label>
              <select
                value={course}
                onChange={(e) => handleCourseChange(e.target.value as CourseType)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="B.Tech">B.Tech</option>
                <option value="Diploma">Diploma</option>
                <option value="Other">Other</option>
              </select>
            </div>

            {/* Department */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Department</label>
              <select
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 truncate"
              >
                {departments.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {department === 'Other' && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Custom Department Name <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                placeholder="e.g. Mechatronics Engineering"
                value={customDepartment}
                onChange={(e) => setCustomDepartment(e.target.value)}
                required
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          )}

          {/* Year and Semester */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Academic Year</label>
              <select
                value={year}
                onChange={(e) => handleYearChange(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                {years.map((y) => (
                  <option key={y} value={y}>
                    {y}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Semester</label>
              <select
                value={semester}
                onChange={(e) => setSemester(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                {semesters.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Color Badge Picker */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">Color Tag</label>
            <div className="flex flex-wrap gap-2">
              {SUBJECT_COLORS.map((col) => (
                <button
                  key={col.value}
                  type="button"
                  onClick={() => setColor(col.value)}
                  className={`w-7 h-7 rounded-lg flex items-center justify-center transition-all ${
                    color === col.value ? 'ring-2 ring-offset-2 ring-slate-900 scale-105' : 'hover:scale-105'
                  }`}
                  style={{ backgroundColor: col.value }}
                  title={col.name}
                >
                  {color === col.value && <Check className="w-3.5 h-3.5 text-white" />}
                </button>
              ))}
            </div>
          </div>

          {/* Default Faculty & Room */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Default Faculty</label>
              <input
                type="text"
                placeholder="e.g. Dr. Arvind Sharma"
                value={defaultTeacher}
                onChange={(e) => setDefaultTeacher(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Default Room</label>
              <input
                type="text"
                placeholder="e.g. Lab 402 / Hall B"
                value={defaultRoom}
                onChange={(e) => setDefaultRoom(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          {/* Credits and Description */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Credits</label>
              <input
                type="number"
                min="0"
                max="10"
                value={credits}
                onChange={(e) => setCredits(e.target.value === '' ? '' : Number(e.target.value))}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">Description / Syllabus</label>
              <input
                type="text"
                placeholder="Key topics, syllabus topics, or notes"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          {/* Footer Actions */}
          <div className="flex items-center justify-end gap-2.5 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors shadow-xs cursor-pointer"
            >
              <Check className="w-3.5 h-3.5" />
              <span>{isEditing ? 'Save Changes' : 'Create Subject'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
