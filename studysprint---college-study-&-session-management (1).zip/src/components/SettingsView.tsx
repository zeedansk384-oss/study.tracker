import React, { useState } from 'react';
import {
  Settings,
  Download,
  Upload,
  RotateCcw,
  Check,
  AlertCircle,
  Database,
  Sliders,
  ShieldAlert,
} from 'lucide-react';
import { UserPreferences, CourseType, SessionType } from '../types/academic';
import {
  getDepartmentsForCourse,
  getYearsForCourse,
  getSemestersForCourseAndYear,
  SESSION_TYPES,
} from '../constants/academicData';
import { storageService } from '../services/storageService';

interface SettingsViewProps {
  preferences: UserPreferences;
  onSavePreferences: (prefs: UserPreferences) => void;
  onDataImported: () => void;
  onResetData: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  preferences,
  onSavePreferences,
  onDataImported,
  onResetData,
}) => {
  const [prefs, setPrefs] = useState<UserPreferences>(preferences);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [importMessage, setImportMessage] = useState<{ text: string; isError: boolean } | null>(null);

  const departments = getDepartmentsForCourse(prefs.defaultCourse);
  const years = getYearsForCourse(prefs.defaultCourse);
  const semesters = getSemestersForCourseAndYear(prefs.defaultCourse, prefs.defaultYear);

  const handleCourseChange = (newCourse: CourseType) => {
    const deps = getDepartmentsForCourse(newCourse);
    const yrs = getYearsForCourse(newCourse);
    const sems = getSemestersForCourseAndYear(newCourse, yrs[0]);
    setPrefs({
      ...prefs,
      defaultCourse: newCourse,
      defaultDepartment: deps[0],
      defaultYear: yrs[0],
      defaultSemester: sems[0],
    });
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onSavePreferences(prefs);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  // Export JSON file
  const handleExport = () => {
    const dataStr = storageService.exportData();
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `studysprint-backup-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Import JSON file
  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const res = storageService.importData(content);
      if (res.success) {
        setImportMessage({ text: res.message, isError: false });
        onDataImported();
      } else {
        setImportMessage({ text: res.message, isError: true });
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Settings & Data Management
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Configure default academic presets, download JSON backups, and manage stored study data.
          </p>
        </div>
      </div>

      {/* Academic Default Presets */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-xs">
        <div className="flex items-center gap-2.5 pb-4 border-b border-slate-100 dark:border-slate-800">
          <Sliders className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
          <h3 className="text-base font-bold text-slate-900 dark:text-white">Default Academic Profile</h3>
        </div>

        <form onSubmit={handleSave} className="space-y-4 pt-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Default Course */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Default Program
              </label>
              <select
                value={prefs.defaultCourse}
                onChange={(e) => handleCourseChange(e.target.value as CourseType)}
                className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="B.Tech">B.Tech</option>
                <option value="Diploma">Diploma</option>
                <option value="Other">Other</option>
              </select>
            </div>

            {/* Default Department */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Default Department
              </label>
              <select
                value={prefs.defaultDepartment}
                onChange={(e) => setPrefs({ ...prefs, defaultDepartment: e.target.value })}
                className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 truncate"
              >
                {departments.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Default Year */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Default Academic Year
              </label>
              <select
                value={prefs.defaultYear}
                onChange={(e) => setPrefs({ ...prefs, defaultYear: e.target.value })}
                className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                {years.map((y) => (
                  <option key={y} value={y}>
                    {y}
                  </option>
                ))}
              </select>
            </div>

            {/* Default Semester */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Default Semester
              </label>
              <select
                value={prefs.defaultSemester}
                onChange={(e) => setPrefs({ ...prefs, defaultSemester: e.target.value })}
                className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                {semesters.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Default Duration */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Default Session Duration (Minutes)
              </label>
              <input
                type="number"
                min="15"
                max="240"
                step="15"
                value={prefs.defaultSessionDuration}
                onChange={(e) =>
                  setPrefs({ ...prefs, defaultSessionDuration: Number(e.target.value) })
                }
                className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            {/* Default Session Type */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Default Session Type
              </label>
              <select
                value={prefs.defaultSessionType}
                onChange={(e) =>
                  setPrefs({ ...prefs, defaultSessionType: e.target.value as SessionType })
                }
                className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                {SESSION_TYPES.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-800">
            {saveSuccess ? (
              <span className="inline-flex items-center gap-1.5 text-xs text-emerald-600 dark:text-emerald-400 font-semibold">
                <Check className="w-4 h-4" /> Preferences saved!
              </span>
            ) : (
              <span className="text-xs text-slate-400 dark:text-slate-500">Settings apply to newly created sessions</span>
            )}

            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition-colors shadow-xs cursor-pointer"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Save Preferences</span>
            </button>
          </div>
        </form>
      </div>

      {/* Data Backup & Restore */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-xs space-y-4">
        <div className="flex items-center gap-2.5 pb-4 border-b border-slate-100 dark:border-slate-800">
          <Database className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
          <h3 className="text-base font-bold text-slate-900 dark:text-white">Data Backup & Restore (JSON)</h3>
        </div>

        <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
          StudySprint saves all sessions and subjects in your browser storage. You can export a JSON backup file to keep your study data safe or restore it on another device.
        </p>

        {importMessage && (
          <div
            className={`p-3 rounded-xl text-xs flex items-center gap-2 ${
              importMessage.isError
                ? 'bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-900'
                : 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-900'
            }`}
          >
            {importMessage.isError ? (
              <AlertCircle className="w-4 h-4 shrink-0" />
            ) : (
              <Check className="w-4 h-4 shrink-0" />
            )}
            <span>{importMessage.text}</span>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
          {/* Download Full Project ZIP */}
          <div className="p-4 rounded-xl border border-indigo-200 dark:border-indigo-900/60 bg-indigo-50/40 dark:bg-indigo-950/30 space-y-3">
            <div>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">Project Source (.ZIP)</h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Download the complete codebase and assets as a ZIP archive.
              </p>
            </div>
            <a
              href="/studysprint-project.zip"
              download="studysprint-project.zip"
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs transition-colors cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Download Project ZIP</span>
            </a>
          </div>

          {/* Export JSON Button */}
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 space-y-3">
            <div>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">Export JSON</h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Download all subjects and sessions as a structured JSON file.
              </p>
            </div>
            <button
              type="button"
              onClick={handleExport}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-50 border border-slate-300 dark:border-slate-700 rounded-lg shadow-xs transition-colors cursor-pointer"
            >
              <Download className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              <span>Download JSON</span>
            </button>
          </div>

          {/* Import Button */}
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 space-y-3">
            <div>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">Restore Backup</h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Upload a previously exported JSON backup file.
              </p>
            </div>
            <label className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-50 border border-slate-300 dark:border-slate-700 rounded-lg shadow-xs transition-colors cursor-pointer">
              <Upload className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              <span>Select JSON File</span>
              <input
                type="file"
                accept=".json"
                onChange={handleImport}
                className="hidden"
              />
            </label>
          </div>
        </div>
      </div>

      {/* Danger Zone: Reset to sample data */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-rose-200 dark:border-rose-900/60 p-6 shadow-xs space-y-3">
        <div className="flex items-center gap-2.5">
          <ShieldAlert className="w-5 h-5 text-rose-600" />
          <h3 className="text-base font-bold text-slate-900 dark:text-white">Demo Data Reset</h3>
        </div>
        <p className="text-xs text-slate-600 dark:text-slate-300">
          Restore the initial realistic B.Tech and Diploma sample data with all subjects and sessions.
        </p>
        <button
          type="button"
          onClick={() => {
            if (window.confirm('Reset all sessions and subjects to initial sample data? Current custom entries will be replaced.')) {
              onResetData();
            }
          }}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-rose-700 dark:text-rose-300 bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 border border-rose-200 dark:border-rose-900 rounded-lg transition-colors cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset to Fresh Demo Data</span>
        </button>
      </div>
    </div>
  );
};
