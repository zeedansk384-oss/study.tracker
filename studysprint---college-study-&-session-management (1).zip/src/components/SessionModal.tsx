import React, { useState, useEffect } from 'react';
import { Calendar, Clock, X, Check, AlertCircle, Plus, BookOpen, Layers } from 'lucide-react';
import { Session, Subject, CourseType, SessionType, SessionStatus } from '../types/academic';
import {
  getDepartmentsForCourse,
  getYearsForCourse,
  getSemestersForCourseAndYear,
  SESSION_TYPES,
  SUBJECT_COLORS,
} from '../constants/academicData';
import { formatDate } from '../services/storageService';

interface SessionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (session: Omit<Session, 'id' | 'createdAt' | 'updatedAt'> | Session) => void;
  initialSession?: Session | null;
  subjects: Subject[];
  onOpenAddSubject?: () => void;
  defaultDate?: string;
  defaultCourse?: CourseType;
}

export const SessionModal: React.FC<SessionModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialSession,
  subjects,
  onOpenAddSubject,
  defaultDate,
  defaultCourse = 'B.Tech',
}) => {
  if (!isOpen) return null;

  const isEditing = Boolean(initialSession);

  // Form State
  const [title, setTitle] = useState(initialSession?.title || '');
  const [course, setCourse] = useState<CourseType>(initialSession?.course || defaultCourse);
  const [department, setDepartment] = useState(
    initialSession?.department || getDepartmentsForCourse(initialSession?.course || defaultCourse)[0]
  );
  const [customDepartment, setCustomDepartment] = useState('');
  const [year, setYear] = useState(
    initialSession?.year || getYearsForCourse(initialSession?.course || defaultCourse)[0]
  );
  const [semester, setSemester] = useState(
    initialSession?.semester ||
      getSemestersForCourseAndYear(
        initialSession?.course || defaultCourse,
        initialSession?.year || getYearsForCourse(initialSession?.course || defaultCourse)[0]
      )[0]
  );
  const [subjectId, setSubjectId] = useState(initialSession?.subjectId || '');
  const [date, setDate] = useState(initialSession?.date || defaultDate || formatDate(new Date()));
  const [startTime, setStartTime] = useState(initialSession?.startTime || '10:00');
  const [endTime, setEndTime] = useState(initialSession?.endTime || '11:30');
  const [sessionType, setSessionType] = useState<SessionType>(initialSession?.sessionType || 'Lecture');
  const [customSessionType, setCustomSessionType] = useState(initialSession?.customSessionType || '');
  const [teacher, setTeacher] = useState(initialSession?.teacher || '');
  const [room, setRoom] = useState(initialSession?.room || '');
  const [notes, setNotes] = useState(initialSession?.notes || '');
  const [status, setStatus] = useState<SessionStatus>(initialSession?.status || 'Scheduled');
  const [error, setError] = useState<string | null>(null);

  // Filter subjects for the selected course/department/year
  const availableSubjects = subjects.filter((s) => {
    if (s.course !== course) return false;
    return true;
  });

  // When initialSession changes, sync state
  useEffect(() => {
    if (initialSession) {
      setTitle(initialSession.title);
      setCourse(initialSession.course);
      setDepartment(initialSession.department);
      setYear(initialSession.year);
      setSemester(initialSession.semester);
      setSubjectId(initialSession.subjectId);
      setDate(initialSession.date);
      setStartTime(initialSession.startTime);
      setEndTime(initialSession.endTime);
      setSessionType(initialSession.sessionType);
      setCustomSessionType(initialSession.customSessionType || '');
      setTeacher(initialSession.teacher || '');
      setRoom(initialSession.room || '');
      setNotes(initialSession.notes || '');
      setStatus(initialSession.status);
    } else {
      // Set initial subjectId if not set
      if (availableSubjects.length > 0 && !subjectId) {
        setSubjectId(availableSubjects[0].id);
        if (availableSubjects[0].defaultTeacher) setTeacher(availableSubjects[0].defaultTeacher);
        if (availableSubjects[0].defaultRoom) setRoom(availableSubjects[0].defaultRoom);
      }
    }
  }, [initialSession]);

  // Handle course change
  const handleCourseChange = (newCourse: CourseType) => {
    setCourse(newCourse);
    const deps = getDepartmentsForCourse(newCourse);
    setDepartment(deps[0]);
    const yrs = getYearsForCourse(newCourse);
    setYear(yrs[0]);
    const sems = getSemestersForCourseAndYear(newCourse, yrs[0]);
    setSemester(sems[0]);

    // Choose relevant subject
    const courseSubs = subjects.filter((s) => s.course === newCourse);
    if (courseSubs.length > 0) {
      setSubjectId(courseSubs[0].id);
      if (courseSubs[0].defaultTeacher) setTeacher(courseSubs[0].defaultTeacher || '');
      if (courseSubs[0].defaultRoom) setRoom(courseSubs[0].defaultRoom || '');
    } else {
      setSubjectId('');
    }
  };

  // Handle subject change to autofill teacher & room if empty
  const handleSubjectChange = (newSubId: string) => {
    setSubjectId(newSubId);
    const selectedSub = subjects.find((s) => s.id === newSubId);
    if (selectedSub) {
      if (!teacher && selectedSub.defaultTeacher) setTeacher(selectedSub.defaultTeacher);
      if (!room && selectedSub.defaultRoom) setRoom(selectedSub.defaultRoom);
      if (selectedSub.course) setCourse(selectedSub.course);
      if (selectedSub.department) setDepartment(selectedSub.department);
      if (selectedSub.year) setYear(selectedSub.year);
      if (selectedSub.semester) setSemester(selectedSub.semester);
    }
  };

  const departments = getDepartmentsForCourse(course);
  const years = getYearsForCourse(course);
  const semesters = getSemestersForCourseAndYear(course, year);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setError('Session title is required');
      return;
    }
    if (!subjectId) {
      setError('Please select a subject or create one');
      return;
    }
    if (!date) {
      setError('Date is required');
      return;
    }
    if (!startTime || !endTime) {
      setError('Start time and end time are required');
      return;
    }
    if (endTime <= startTime) {
      setError('End time must be after start time');
      return;
    }

    const selectedSub = subjects.find((s) => s.id === subjectId);
    const finalDepartment = department === 'Other' ? (customDepartment.trim() || 'General Studies') : department;

    const payload: any = {
      title: title.trim(),
      subjectId,
      subjectName: selectedSub ? selectedSub.name : 'General Subject',
      subjectCode: selectedSub?.code || undefined,
      course,
      department: finalDepartment,
      year,
      semester,
      date,
      startTime,
      endTime,
      sessionType,
      customSessionType: sessionType === 'Other' ? customSessionType.trim() : undefined,
      teacher: teacher.trim() || undefined,
      room: room.trim() || undefined,
      notes: notes.trim() || undefined,
      status,
      color: selectedSub?.color || SUBJECT_COLORS[0].value,
    };

    if (isEditing && initialSession) {
      onSave({
        ...initialSession,
        ...payload,
      });
    } else {
      onSave(payload);
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div
        className="bg-white dark:bg-slate-900 rounded-2xl max-w-2xl w-full shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden transform transition-all my-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-100 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-400 flex items-center justify-center">
              <Calendar className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                {isEditing ? 'Edit Study Session' : 'Add New Study Session'}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Independent session schedule and academic details
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            type="button"
            className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          {error && (
            <div className="flex items-center gap-2 p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-700">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Title */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Session Title <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              placeholder="e.g. Dynamic Programming & Graph Algorithms"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
              className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Academic Course, Department */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Course Program <span className="text-rose-500">*</span>
              </label>
              <select
                value={course}
                onChange={(e) => handleCourseChange(e.target.value as CourseType)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="B.Tech">B.Tech</option>
                <option value="Diploma">Diploma</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Department <span className="text-rose-500">*</span>
              </label>
              <select
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 truncate"
              >
                {departments.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {department === 'Other' && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Custom Department Name <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                placeholder="e.g. Aerospace Engineering"
                value={customDepartment}
                onChange={(e) => setCustomDepartment(e.target.value)}
                required
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          )}

          {/* Year & Semester */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Academic Year</label>
              <select
                value={year}
                onChange={(e) => {
                  setYear(e.target.value);
                  const sems = getSemestersForCourseAndYear(course, e.target.value);
                  setSemester(sems[0]);
                }}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                {years.map((y) => (
                  <option key={y} value={y}>
                    {y}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Semester</label>
              <select
                value={semester}
                onChange={(e) => setSemester(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                {semesters.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Subject selection with quick "+ New Subject" */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-semibold text-slate-700">
                Subject <span className="text-rose-500">*</span>
              </label>
              {onOpenAddSubject && (
                <button
                  type="button"
                  onClick={onOpenAddSubject}
                  className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold inline-flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>New Subject</span>
                </button>
              )}
            </div>
            <select
              value={subjectId}
              onChange={(e) => handleSubjectChange(e.target.value)}
              required
              className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="" disabled>
                Select a subject...
              </option>
              {availableSubjects.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.code ? `[${s.code}] ` : ''}{s.name} ({s.course})
                </option>
              ))}
            </select>
            {availableSubjects.length === 0 && (
              <p className="text-xs text-amber-600 mt-1">
                No subjects found for {course}. Click &quot;New Subject&quot; above to create one.
              </p>
            )}
          </div>

          {/* Date, Start Time, End Time */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Date <span className="text-rose-500">*</span>
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                required
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Start Time <span className="text-rose-500">*</span>
              </label>
              <input
                type="time"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                required
                className="w-full px-3 py-2 text-sm font-mono tabular-nums bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                End Time <span className="text-rose-500">*</span>
              </label>
              <input
                type="time"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
                required
                className="w-full px-3 py-2 text-sm font-mono tabular-nums bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          {/* Session Type and Status */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Session Type</label>
              <select
                value={sessionType}
                onChange={(e) => setSessionType(e.target.value as SessionType)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                {SESSION_TYPES.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Status</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as SessionStatus)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="Scheduled">Scheduled</option>
                <option value="In Progress">In Progress</option>
                <option value="Completed">Completed</option>
                <option value="Cancelled">Cancelled</option>
                <option value="Rescheduled">Rescheduled</option>
              </select>
            </div>
          </div>

          {sessionType === 'Other' && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Custom Session Type</label>
              <input
                type="text"
                placeholder="e.g. Industry Guest Seminar"
                value={customSessionType}
                onChange={(e) => setCustomSessionType(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          )}

          {/* Teacher and Room */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Faculty / Teacher (Optional)
              </label>
              <input
                type="text"
                placeholder="e.g. Dr. Arvind Sharma"
                value={teacher}
                onChange={(e) => setTeacher(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Room / Venue (Optional)
              </label>
              <input
                type="text"
                placeholder="e.g. Lab 402 / Hall B"
                value={room}
                onChange={(e) => setRoom(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Description / Notes</label>
            <textarea
              rows={2}
              placeholder="Preparation items, homework, chapter reading, submission links..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Footer Actions */}
          <div className="flex items-center justify-end gap-2.5 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors shadow-xs cursor-pointer"
            >
              <Check className="w-3.5 h-3.5" />
              <span>{isEditing ? 'Save Changes' : 'Create Session'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
