import React from 'react';
import {
  Calendar,
  Clock,
  BookOpen,
  Check,
  CheckCircle2,
  AlertCircle,
  Plus,
  Edit3,
  Copy,
  Trash2,
  ArrowRight,
  GraduationCap,
  Sparkles,
  MapPin,
  User,
  SlidersHorizontal,
} from 'lucide-react';
import { Session, Subject, CourseType, AcademicFilterState } from '../types/academic';
import { formatDate, formatTimeRange } from '../services/storageService';

interface DashboardViewProps {
  sessions: Session[];
  subjects: Subject[];
  filters: AcademicFilterState;
  onFilterChange: (filters: AcademicFilterState) => void;
  onOpenAddSession: () => void;
  onEditSession: (session: Session) => void;
  onQuickEditTime: (session: Session) => void;
  onDuplicateSession: (session: Session) => void;
  onDeleteSession: (session: Session) => void;
  onToggleComplete: (session: Session) => void;
  onNavigateToTab: (tab: 'calendar' | 'sessions' | 'subjects' | 'settings') => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  sessions,
  subjects,
  filters,
  onFilterChange,
  onOpenAddSession,
  onEditSession,
  onQuickEditTime,
  onDuplicateSession,
  onDeleteSession,
  onToggleComplete,
  onNavigateToTab,
}) => {
  const todayStr = formatDate(new Date());

  // Filtered dataset
  const filteredSessions = sessions.filter((s) => {
    if (filters.course !== 'All' && s.course !== filters.course) return false;
    if (filters.department !== 'All' && s.department !== filters.department) return false;
    if (filters.year !== 'All' && s.year !== filters.year) return false;
    if (filters.semester !== 'All' && s.semester !== filters.semester) return false;
    if (filters.subjectId !== 'All' && s.subjectId !== filters.subjectId) return false;
    if (filters.sessionType !== 'All' && s.sessionType !== filters.sessionType) return false;
    if (filters.status !== 'All' && s.status !== filters.status) return false;
    if (filters.date && s.date !== filters.date) return false;
    if (filters.searchQuery) {
      const q = filters.searchQuery.toLowerCase();
      const match =
        s.title.toLowerCase().includes(q) ||
        s.subjectName.toLowerCase().includes(q) ||
        (s.teacher && s.teacher.toLowerCase().includes(q)) ||
        (s.room && s.room.toLowerCase().includes(q)) ||
        (s.notes && s.notes.toLowerCase().includes(q));
      if (!match) return false;
    }
    return true;
  });

  const todaySessions = filteredSessions
    .filter((s) => s.date === todayStr)
    .sort((a, b) => a.startTime.localeCompare(b.startTime));

  const upcomingSessions = filteredSessions
    .filter((s) => s.date > todayStr)
    .sort((a, b) => (a.date === b.date ? a.startTime.localeCompare(b.startTime) : a.date.localeCompare(b.date)))
    .slice(0, 5);

  const completedToday = todaySessions.filter((s) => s.status === 'Completed').length;
  const totalCompleted = filteredSessions.filter((s) => s.status === 'Completed').length;

  // Next session determination
  const nextSession =
    todaySessions.find((s) => s.status === 'Scheduled' || s.status === 'In Progress') ||
    upcomingSessions[0];

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-blue-700 via-indigo-700 to-purple-800 rounded-2xl p-6 text-white shadow-md relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 text-indigo-200 text-xs font-semibold tracking-wide uppercase">
              <GraduationCap className="w-4 h-4 text-indigo-200" />
              <span>
                {filters.course === 'All' ? 'All Academic Programs' : `${filters.course} Program`}
                {filters.department !== 'All' ? ` · ${filters.department}` : ''}
                {filters.year !== 'All' ? ` · ${filters.year}` : ''}
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-extrabold tracking-tight text-white">
              StudySprint Academic Dashboard
            </h1>
            <p className="text-xs sm:text-sm text-indigo-100/90 max-w-xl">
              Independent timetable scheduling for college lectures, labs, tutorials, and practical exams.
            </p>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={onOpenAddSession}
              type="button"
              className="inline-flex items-center gap-1.5 px-4 py-2.5 text-xs sm:text-sm font-semibold text-indigo-950 bg-white hover:bg-indigo-50 rounded-xl transition-all shadow-sm whitespace-nowrap cursor-pointer"
            >
              <Plus className="w-4 h-4 text-indigo-600" />
              <span>+ Add Session</span>
            </button>
            <button
              onClick={() => onNavigateToTab('calendar')}
              type="button"
              className="inline-flex items-center gap-1.5 px-3.5 py-2.5 text-xs sm:text-sm font-medium text-white/90 hover:text-white bg-white/10 hover:bg-white/20 border border-white/15 rounded-xl transition-all whitespace-nowrap cursor-pointer"
            >
              <Calendar className="w-4 h-4" />
              <span className="hidden sm:inline">Open Calendar</span>
            </button>
          </div>
        </div>
      </div>

      {/* 4 Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Today's Sessions */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Today&apos;s Sessions</span>
            <Clock className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white tabular-nums font-mono">
              {todaySessions.length}
            </span>
            <span className="text-xs text-slate-500 dark:text-slate-400">
              ({completedToday} done)
            </span>
          </div>
          <div className="mt-2 text-[11px] text-slate-400">
            {todaySessions.length === 0 ? 'No sessions scheduled today' : `${todaySessions.length - completedToday} remaining`}
          </div>
        </div>

        {/* Total Sessions */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Total Sessions</span>
            <Calendar className="w-4 h-4 text-sky-600 dark:text-sky-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white tabular-nums font-mono">
              {filteredSessions.length}
            </span>
            <span className="text-xs text-slate-500 dark:text-slate-400">active</span>
          </div>
          <div className="mt-2 text-[11px] text-slate-400">
            {totalCompleted} marked completed
          </div>
        </div>

        {/* Total Subjects */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Total Subjects</span>
            <BookOpen className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900 dark:text-white tabular-nums font-mono">
              {subjects.length}
            </span>
            <span className="text-xs text-slate-500 dark:text-slate-400">enrolled</span>
          </div>
          <div className="mt-2 text-[11px] text-slate-400">
            B.Tech & Diploma tracks
          </div>
        </div>

        {/* Program Status */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Course Filter</span>
            <GraduationCap className="w-4 h-4 text-amber-600 dark:text-amber-400" />
          </div>
          <div className="mt-2">
            <span className="text-lg font-bold text-slate-900 dark:text-white truncate block">
              {filters.course}
            </span>
          </div>
          <div className="mt-2 text-[11px] text-slate-500 dark:text-slate-400 truncate">
            {filters.department === 'All' ? 'All Departments' : filters.department}
          </div>
        </div>
      </div>

      {/* Next Upcoming Session Spotlight */}
      {nextSession && (
        <div className="bg-white dark:bg-slate-900 border-l-4 border-indigo-600 dark:border-indigo-500 rounded-2xl p-5 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
            <div>
              <div className="flex items-center gap-2 text-xs font-semibold text-indigo-700 dark:text-indigo-400">
                <span className="inline-block w-2 h-2 rounded-full bg-indigo-600 animate-pulse"></span>
                <span>Next Upcoming Session</span>
                <span className="text-slate-400">·</span>
                <span className="font-mono tabular-nums text-slate-600 dark:text-slate-300">
                  {nextSession.date === todayStr ? 'Today' : nextSession.date}
                </span>
              </div>

              <h3 className="text-lg font-bold text-slate-900 dark:text-white mt-1">
                {nextSession.title}
              </h3>
              <div className="text-sm font-semibold text-indigo-600 dark:text-indigo-400 mt-0.5">
                {nextSession.subjectName}
              </div>
            </div>

            <div className="self-start sm:self-auto bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 px-3 py-1 rounded-full text-xs font-mono font-bold flex items-center gap-1.5 shadow-2xs whitespace-nowrap">
              <Clock className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" />
              <span>{formatTimeRange(nextSession.startTime, nextSession.endTime)}</span>
            </div>
          </div>

          {/* Tags */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 border border-blue-200/60 dark:border-blue-900/60 rounded-full px-2.5 py-0.5 text-xs font-semibold">
              {nextSession.course}
            </span>
            <span className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-full px-2.5 py-0.5 text-xs font-medium">
              {nextSession.department}
            </span>
            <span className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-full px-2.5 py-0.5 text-xs font-medium">
              {nextSession.year.replace('Year', 'Yr')} · {nextSession.semester.replace('Semester ', 'Sem ')}
            </span>
            <span className="bg-sky-50 dark:bg-sky-950/40 text-sky-700 dark:text-sky-300 border border-sky-200/60 rounded-full px-2.5 py-0.5 text-xs font-semibold">
              {nextSession.sessionType}
            </span>
          </div>

          {/* Details */}
          <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-xs text-slate-600 dark:text-slate-300">
            <div className="flex items-center gap-1 font-mono">
              <span>🗓️</span>
              <span>{nextSession.date}</span>
            </div>
            {nextSession.teacher && (
              <div className="flex items-center gap-1 font-medium">
                <span>👨‍🏫</span>
                <span>{nextSession.teacher}</span>
              </div>
            )}
            {nextSession.room && (
              <div className="flex items-center gap-1">
                <span>📍</span>
                <span>{nextSession.room}</span>
              </div>
            )}
          </div>

          {nextSession.notes && (
            <div className="bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 rounded-xl p-3 text-xs sm:text-sm text-slate-600 dark:text-slate-300">
              {nextSession.notes}
            </div>
          )}

          {/* Actions */}
          <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => onEditSession(nextSession)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-2xs cursor-pointer"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>Edit</span>
            </button>
            <button
              type="button"
              onClick={() => onQuickEditTime(nextSession)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-sky-500 hover:bg-sky-600 rounded-lg shadow-2xs cursor-pointer"
            >
              <Clock className="w-3.5 h-3.5" />
              <span>Change Time</span>
            </button>
            <button
              type="button"
              onClick={() => onToggleComplete(nextSession)}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg shadow-2xs cursor-pointer ${
                nextSession.status === 'Completed'
                  ? 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                  : 'bg-emerald-500 hover:bg-emerald-600 text-white'
              }`}
            >
              <Check className="w-3.5 h-3.5" />
              <span>{nextSession.status === 'Completed' ? 'Mark Pending' : 'Done'}</span>
            </button>
          </div>
        </div>
      )}

      {/* Main Grid: Today's Schedule & Upcoming Sessions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Today's Schedule Timeline (2 Cols on LG) */}
        <div className="lg:col-span-2 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-slate-500 dark:text-slate-400" />
              <h2 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white">
                Today&apos;s Schedule
              </h2>
              <span className="text-xs font-mono tabular-nums text-slate-400">({todayStr})</span>
            </div>
            <button
              onClick={() => onNavigateToTab('calendar')}
              className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1 cursor-pointer"
            >
              <span>Full Calendar</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {todaySessions.length === 0 ? (
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-8 text-center space-y-3">
              <div className="w-12 h-12 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-400 mx-auto flex items-center justify-center">
                <Calendar className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200">
                  No sessions scheduled for today
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-sm mx-auto">
                  Add a session for today or check the upcoming sessions list.
                </p>
              </div>
              <button
                onClick={onOpenAddSession}
                type="button"
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition-colors shadow-xs cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Add Today&apos;s Session</span>
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {todaySessions.map((sess) => {
                const isCompleted = sess.status === 'Completed';
                return (
                  <div
                    key={sess.id}
                    className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm p-5 border-l-4 border-indigo-600 dark:border-indigo-500 transition-all hover:shadow-md space-y-2.5"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                      <div>
                        <h4
                          className={`text-base font-bold text-slate-900 dark:text-white leading-tight ${
                            isCompleted ? 'line-through text-slate-500 dark:text-slate-400' : ''
                          }`}
                        >
                          {sess.title}
                        </h4>
                        <div className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 mt-0.5">
                          {sess.subjectName}
                        </div>
                      </div>

                      <div className="self-start sm:self-auto bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 px-3 py-1 rounded-full text-xs font-mono font-bold flex items-center gap-1.5 shadow-2xs whitespace-nowrap">
                        <Clock className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" />
                        <span>{formatTimeRange(sess.startTime, sess.endTime)}</span>
                      </div>
                    </div>

                    {/* Tag row */}
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 border border-blue-200/60 rounded-full px-2.5 py-0.5 text-xs font-semibold">
                        {sess.course}
                      </span>
                      <span className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-full px-2.5 py-0.5 text-xs font-medium">
                        {sess.department}
                      </span>
                      <span className="bg-sky-50 dark:bg-sky-950/40 text-sky-700 dark:text-sky-300 rounded-full px-2.5 py-0.5 text-xs font-semibold">
                        {sess.sessionType}
                      </span>
                      <span className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-full px-2.5 py-0.5 text-xs font-medium">
                        {sess.status}
                      </span>
                    </div>

                    {/* Location, teacher */}
                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-600 dark:text-slate-300">
                      {sess.room && <span>📍 {sess.room}</span>}
                      {sess.teacher && <span>👨‍🏫 {sess.teacher}</span>}
                    </div>

                    {/* Action buttons */}
                    <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                      <button
                        type="button"
                        onClick={() => onEditSession(sess)}
                        className="px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-2xs cursor-pointer flex items-center gap-1.5"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        <span>Edit</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => onQuickEditTime(sess)}
                        className="px-3 py-1.5 text-xs font-semibold text-white bg-sky-500 hover:bg-sky-600 rounded-lg shadow-2xs cursor-pointer flex items-center gap-1.5"
                      >
                        <Clock className="w-3.5 h-3.5" />
                        <span>Change Time</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => onDuplicateSession(sess)}
                        className="px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-50 border border-slate-200 dark:border-slate-700 rounded-lg shadow-2xs cursor-pointer flex items-center gap-1.5"
                      >
                        <Copy className="w-3.5 h-3.5 text-slate-500" />
                        <span>Duplicate</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => onToggleComplete(sess)}
                        className={`px-3 py-1.5 text-xs font-semibold rounded-lg shadow-2xs cursor-pointer flex items-center gap-1.5 ${
                          isCompleted
                            ? 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                            : 'bg-emerald-500 hover:bg-emerald-600 text-white'
                        }`}
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>{isCompleted ? 'Pending' : 'Done'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => onDeleteSession(sess)}
                        className="px-3 py-1.5 text-xs font-medium text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 rounded-lg shadow-2xs cursor-pointer flex items-center gap-1.5 ml-auto"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Delete</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Right Column: Upcoming Sessions & Subjects Overview */}
        <div className="space-y-6">
          {/* Upcoming Sessions Box */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-4 sm:p-5 shadow-xs space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">Upcoming Sessions</h3>
              <button
                onClick={() => onNavigateToTab('sessions')}
                className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
              >
                View All
              </button>
            </div>

            {upcomingSessions.length === 0 ? (
              <p className="text-xs text-slate-500 dark:text-slate-400 py-3 text-center">
                No future sessions scheduled.
              </p>
            ) : (
              <div className="space-y-3">
                {upcomingSessions.map((s) => (
                  <div
                    key={s.id}
                    className="p-3 rounded-xl border border-slate-100 dark:border-slate-800 hover:border-slate-200 dark:hover:border-slate-700 bg-slate-50/50 dark:bg-slate-800/40 space-y-1.5 transition-all"
                  >
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-indigo-600 dark:text-indigo-400">
                        {s.subjectName}
                      </span>
                      <span className="font-mono tabular-nums text-slate-500 dark:text-slate-400">
                        {s.date}
                      </span>
                    </div>
                    <div className="text-xs font-bold text-slate-900 dark:text-white truncate">
                      {s.title}
                    </div>
                    <div className="flex items-center justify-between pt-1 text-[11px]">
                      <span className="font-mono tabular-nums text-slate-500 dark:text-slate-400">
                        {formatTimeRange(s.startTime, s.endTime)}
                      </span>
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => onQuickEditTime(s)}
                          className="font-semibold text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
                        >
                          Change Time
                        </button>
                        <span className="text-slate-300 dark:text-slate-700">·</span>
                        <button
                          type="button"
                          onClick={() => onEditSession(s)}
                          className="text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white cursor-pointer"
                        >
                          Edit
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Quick Enrolled Subjects Preview */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-4 sm:p-5 shadow-xs space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">Curriculum Subjects</h3>
              <button
                onClick={() => onNavigateToTab('subjects')}
                className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
              >
                Manage
              </button>
            </div>
            <div className="space-y-2">
              {subjects.slice(0, 5).map((sub) => {
                const subSessionCount = sessions.filter((s) => s.subjectId === sub.id).length;
                return (
                  <div
                    key={sub.id}
                    className="flex items-center justify-between text-xs p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60"
                  >
                    <div className="flex items-center gap-2 truncate">
                      <span
                        className="w-2.5 h-2.5 rounded-full shrink-0"
                        style={{ backgroundColor: sub.color }}
                      />
                      <span className="font-semibold text-slate-800 dark:text-slate-200 truncate">
                        {sub.name}
                      </span>
                    </div>
                    <span className="text-[11px] font-mono tabular-nums text-slate-500 dark:text-slate-400 shrink-0">
                      {subSessionCount} sessions
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
