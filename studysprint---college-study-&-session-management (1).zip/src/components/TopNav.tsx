import React, { useState } from 'react';
import { Plus, GraduationCap, Menu, X, Calendar, LayoutDashboard, ListFilter, BookMarked, Settings as SettingsIcon, Download } from 'lucide-react';
import { CourseType } from '../types/academic';

export type ActiveTab = 'dashboard' | 'calendar' | 'sessions' | 'subjects' | 'settings';

interface TopNavProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  onOpenAddSession: () => void;
  activeCourse: string;
  onSelectCourse: (course: string) => void;
  totalSessionsCount: number;
}

export const TopNav: React.FC<TopNavProps> = ({
  activeTab,
  setActiveTab,
  onOpenAddSession,
  activeCourse,
  onSelectCourse,
  totalSessionsCount,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems: { id: ActiveTab; label: string; icon: React.ReactNode }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="w-4 h-4" /> },
    { id: 'calendar', label: 'Calendar', icon: <Calendar className="w-4 h-4" /> },
    { id: 'sessions', label: 'Sessions', icon: <ListFilter className="w-4 h-4" /> },
    { id: 'subjects', label: 'Subjects', icon: <BookMarked className="w-4 h-4" /> },
    { id: 'settings', label: 'Settings', icon: <SettingsIcon className="w-4 h-4" /> },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Zone 1: Single element brand mark */}
          <div className="flex items-center gap-4">
            <button
              onClick={() => setActiveTab('dashboard')}
              className="flex items-center gap-2.5 text-left group focus:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 rounded-md"
            >
              <div className="w-9 h-9 rounded-lg bg-indigo-600 flex items-center justify-center text-white shadow-xs group-hover:bg-indigo-700 transition-colors">
                <GraduationCap className="w-5 h-5" />
              </div>
              <div className="leading-tight">
                <span className="text-lg font-bold tracking-tight text-slate-900 group-hover:text-indigo-600 transition-colors">
                  StudySprint
                </span>
                <span className="hidden sm:block text-[11px] font-medium text-slate-500">
                  B.Tech & Diploma Academic Planner
                </span>
              </div>
            </button>

            {/* Quick Course Switcher Segmented Control */}
            <div className="hidden lg:flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200/60 ml-3">
              {(['All', 'B.Tech', 'Diploma'] as const).map((c) => {
                const isSelected = activeCourse === c;
                return (
                  <button
                    key={c}
                    type="button"
                    onClick={() => onSelectCourse(c)}
                    className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-all whitespace-nowrap ${
                      isSelected
                        ? 'bg-white text-indigo-700 shadow-xs border border-slate-200/50'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {c}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Zone 2: 4-6 text navigation links */}
          <nav className="hidden md:flex items-center gap-1">
            {navItems.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center gap-1.5 px-3 py-2 text-sm font-medium rounded-lg transition-colors whitespace-nowrap ${
                    isActive
                      ? 'text-indigo-700 bg-indigo-50/70 font-semibold'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`}
                >
                  {item.icon}
                  <span>{item.label}</span>
                  {item.id === 'sessions' && (
                    <span className="text-xs font-mono tabular-nums text-slate-400 bg-slate-100 px-1.5 py-0.2 rounded-md">
                      {totalSessionsCount}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Primary action button, ZIP download & mobile trigger */}
          <div className="flex items-center gap-2">
            <a
              href="/studysprint-project.zip"
              download="studysprint-project.zip"
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 text-xs sm:text-sm font-medium text-slate-700 hover:text-indigo-700 bg-slate-100 hover:bg-indigo-50 border border-slate-200/80 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
              title="Download Project Source Code ZIP Archive"
            >
              <Download className="w-4 h-4 text-indigo-600" />
              <span>Download ZIP</span>
            </a>

            <button
              onClick={onOpenAddSession}
              type="button"
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs sm:text-sm font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 active:bg-indigo-800 transition-colors shadow-xs whitespace-nowrap cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 focus-visible:ring-offset-2"
            >
              <Plus className="w-4 h-4" />
              <span>Add Session</span>
            </button>

            {/* Mobile menu button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              type="button"
              className="md:hidden p-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 focus:outline-none"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-4 space-y-2">
          {/* Quick Course Switcher in Mobile */}
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <span className="text-xs font-semibold text-slate-500">Target Course</span>
            <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200">
              {(['All', 'B.Tech', 'Diploma'] as const).map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => onSelectCourse(c)}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md ${
                    activeCourse === c ? 'bg-white text-indigo-700 shadow-xs' : 'text-slate-600'
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-1.5 pt-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`flex items-center gap-2 px-3 py-2 text-sm font-medium rounded-lg text-left transition-colors ${
                  activeTab === item.id
                    ? 'bg-indigo-50 text-indigo-700 font-semibold'
                    : 'text-slate-700 hover:bg-slate-50'
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
              </button>
            ))}
          </div>

          <div className="pt-2 border-t border-slate-100">
            <a
              href="/studysprint-project.zip"
              download="studysprint-project.zip"
              className="flex items-center justify-center gap-2 w-full py-2 text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200/60 rounded-lg transition-colors cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Download Project Code (.ZIP)</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
