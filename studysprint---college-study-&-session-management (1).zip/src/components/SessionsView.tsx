import React from 'react';
import {
  Plus,
  Search,
  RotateCcw,
  Calendar as CalendarIcon,
  Clock,
  Edit3,
  Copy,
  Check,
  Trash2,
  MapPin,
  User,
  X,
} from 'lucide-react';
import { Session, Subject, SessionStatus, AcademicFilterState, CourseType } from '../types/academic';
import {
  getDepartmentsForCourse,
  getYearsForCourse,
  getSemestersForCourseAndYear,
  SESSION_TYPES,
} from '../constants/academicData';
import { formatTimeRange } from '../services/storageService';

interface SessionsViewProps {
  sessions: Session[];
  subjects: Subject[];
  filters: AcademicFilterState;
  onFilterChange: (filters: AcademicFilterState) => void;
  onOpenAddSession: () => void;
  onEditSession: (session: Session) => void;
  onQuickEditTime: (session: Session) => void;
  onDuplicateSession: (session: Session) => void;
  onDeleteSession: (session: Session) => void;
  onStatusChange: (session: Session, newStatus: SessionStatus) => void;
}

export const SessionsView: React.FC<SessionsViewProps> = ({
  sessions,
  subjects,
  filters,
  onFilterChange,
  onOpenAddSession,
  onEditSession,
  onQuickEditTime,
  onDuplicateSession,
  onDeleteSession,
  onStatusChange,
}) => {
  const departments = getDepartmentsForCourse(filters.course as CourseType);
  const years = getYearsForCourse(filters.course as CourseType);
  const semesters = getSemestersForCourseAndYear(
    filters.course as CourseType,
    filters.year !== 'All' ? filters.year : undefined
  );

  const filteredSubjects = subjects.filter((s) => {
    if (filters.course !== 'All' && s.course !== filters.course) return false;
    if (filters.department !== 'All' && s.department !== filters.department) return false;
    if (filters.year !== 'All' && s.year !== filters.year) return false;
    return true;
  });

  const handleClearFilters = () => {
    onFilterChange({
      course: 'All',
      department: 'All',
      year: 'All',
      semester: 'All',
      subjectId: 'All',
      sessionType: 'All',
      status: 'All',
      date: undefined,
      searchQuery: '',
    });
  };

  const hasActiveFilters =
    filters.course !== 'All' ||
    filters.department !== 'All' ||
    filters.year !== 'All' ||
    filters.semester !== 'All' ||
    filters.subjectId !== 'All' ||
    filters.sessionType !== 'All' ||
    filters.status !== 'All' ||
    Boolean(filters.date) ||
    Boolean(filters.searchQuery);

  // Sort sessions
  const sortedSessions = [...sessions].sort((a, b) => {
    if (a.date === b.date) {
      return a.startTime.localeCompare(b.startTime);
    }
    return b.date.localeCompare(a.date);
  });

  return (
    <div className="space-y-5">
      {/* Header section */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Sessions
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Manage every lecture, lab, practical, revision and study session. Every session time is 100% editable independently.
          </p>
        </div>

        <button
          onClick={onOpenAddSession}
          type="button"
          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs sm:text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition-all shadow-sm self-start sm:self-center cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>+ Add Session</span>
        </button>
      </div>

      {/* Filter Card Container */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-4 sm:p-5 shadow-xs space-y-3.5">
        {/* Full width Search input */}
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search sessions by title, subject, teacher, room or notes..."
            value={filters.searchQuery}
            onChange={(e) => onFilterChange({ ...filters, searchQuery: e.target.value })}
            className="w-full pl-10 pr-9 py-2 text-xs sm:text-sm bg-slate-50/70 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white dark:focus:bg-slate-800 transition-all"
          />
          {filters.searchQuery && (
            <button
              onClick={() => onFilterChange({ ...filters, searchQuery: '' })}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Row 1: Course, Department, Year, Semester, Subject, Date, Type */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-2.5">
          {/* Courses */}
          <select
            value={filters.course}
            onChange={(e) =>
              onFilterChange({
                ...filters,
                course: e.target.value,
                department: 'All',
                year: 'All',
                semester: 'All',
                subjectId: 'All',
              })
            }
            className="text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-2.5 py-2 text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="All">All Courses</option>
            <option value="B.Tech">B.Tech</option>
            <option value="Diploma">Diploma</option>
          </select>

          {/* Department */}
          <select
            value={filters.department}
            onChange={(e) =>
              onFilterChange({
                ...filters,
                department: e.target.value,
                subjectId: 'All',
              })
            }
            className="text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-2.5 py-2 text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 truncate"
          >
            <option value="All">All Departments</option>
            {departments.map((d) => (
              <option key={d} value={d}>
                {d}
              </option>
            ))}
          </select>

          {/* Years */}
          <select
            value={filters.year}
            onChange={(e) =>
              onFilterChange({
                ...filters,
                year: e.target.value,
                semester: 'All',
                subjectId: 'All',
              })
            }
            className="text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-2.5 py-2 text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="All">All Years</option>
            {years.map((y) => (
              <option key={y} value={y}>
                {y}
              </option>
            ))}
          </select>

          {/* Semester */}
          <select
            value={filters.semester}
            onChange={(e) => onFilterChange({ ...filters, semester: e.target.value })}
            className="text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-2.5 py-2 text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="All">All Semesters</option>
            {semesters.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>

          {/* Subject */}
          <select
            value={filters.subjectId}
            onChange={(e) => onFilterChange({ ...filters, subjectId: e.target.value })}
            className="text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-2.5 py-2 text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 truncate"
          >
            <option value="All">All Subjects</option>
            {filteredSubjects.map((s) => (
              <option key={s.id} value={s.id}>
                {s.code ? `[${s.code}] ` : ''}{s.name}
              </option>
            ))}
          </select>

          {/* Date Picker */}
          <div className="relative">
            <input
              type="date"
              value={filters.date || ''}
              onChange={(e) => onFilterChange({ ...filters, date: e.target.value || undefined })}
              className="w-full text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-2.5 py-2 text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
            />
          </div>

          {/* Types */}
          <select
            value={filters.sessionType}
            onChange={(e) => onFilterChange({ ...filters, sessionType: e.target.value })}
            className="text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-2.5 py-2 text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="All">All Types</option>
            {SESSION_TYPES.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
        </div>

        {/* Row 2: Status & Clear Filters */}
        <div className="flex items-center gap-3 pt-1">
          <select
            value={filters.status}
            onChange={(e) => onFilterChange({ ...filters, status: e.target.value })}
            className="text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="All">All Statuses</option>
            <option value="Scheduled">Scheduled</option>
            <option value="In Progress">In Progress</option>
            <option value="Completed">Completed</option>
            <option value="Cancelled">Cancelled</option>
            <option value="Rescheduled">Rescheduled</option>
          </select>

          {hasActiveFilters && (
            <button
              type="button"
              onClick={handleClearFilters}
              className="px-3.5 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 border border-slate-200 dark:border-slate-700 rounded-xl transition-colors cursor-pointer"
            >
              Clear Filters
            </button>
          )}
        </div>
      </div>

      {/* Results Count */}
      <div className="text-sm font-bold text-slate-700 dark:text-slate-300">
        {sortedSessions.length} {sortedSessions.length === 1 ? 'Session' : 'Sessions'} Found
      </div>

      {/* Sessions Cards List */}
      {sortedSessions.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-12 text-center space-y-3">
          <div className="w-12 h-12 rounded-xl bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 mx-auto flex items-center justify-center">
            <CalendarIcon className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">No sessions found</h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto">
            Try adjusting your search criteria or add a new session to your academic timetable.
          </p>
          <button
            onClick={onOpenAddSession}
            type="button"
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition-colors shadow-xs cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Create Session</span>
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {sortedSessions.map((sess) => {
            const isCompleted = sess.status === 'Completed';

            return (
              <div
                key={sess.id}
                className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm p-5 border-l-4 border-indigo-600 dark:border-indigo-500 transition-all hover:shadow-md space-y-3"
              >
                {/* Top Row: Title on Left, Time badge on Right */}
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                  <div>
                    <h3
                      className={`text-lg font-bold text-slate-900 dark:text-white leading-tight ${
                        isCompleted ? 'line-through text-slate-500 dark:text-slate-400' : ''
                      }`}
                    >
                      {sess.title}
                    </h3>

                    {/* Subject Subtitle in blue/indigo */}
                    <div className="text-sm font-semibold text-indigo-600 dark:text-indigo-400 mt-0.5">
                      {sess.subjectName}
                    </div>
                  </div>

                  {/* Time chip */}
                  <div className="self-start sm:self-auto bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 px-3 py-1 rounded-full text-xs font-mono font-bold flex items-center gap-1.5 shadow-2xs whitespace-nowrap">
                    <Clock className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" />
                    <span>{formatTimeRange(sess.startTime, sess.endTime)}</span>
                  </div>
                </div>

                {/* Tag Pills Row */}
                <div className="flex flex-wrap items-center gap-2 pt-0.5">
                  {/* Course tag */}
                  <span className="bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 border border-blue-200/60 dark:border-blue-900/60 rounded-full px-2.5 py-0.5 text-xs font-semibold">
                    {sess.course}
                  </span>

                  {/* Department tag */}
                  <span className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-full px-2.5 py-0.5 text-xs font-medium">
                    {sess.department}
                  </span>

                  {/* Year & Sem */}
                  <span className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-full px-2.5 py-0.5 text-xs font-medium">
                    {sess.year.replace('Year', 'Yr')} · {sess.semester.replace('Semester ', 'Sem ')}
                  </span>

                  {/* Session Type */}
                  <span className="bg-sky-50 dark:bg-sky-950/40 text-sky-700 dark:text-sky-300 border border-sky-200/60 dark:border-sky-900/60 rounded-full px-2.5 py-0.5 text-xs font-semibold">
                    {sess.sessionType}
                  </span>

                  {/* Status */}
                  <span
                    className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${
                      sess.status === 'Completed'
                        ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200/60 dark:border-emerald-900/60'
                        : sess.status === 'In Progress'
                        ? 'bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 border border-amber-200/60 dark:border-amber-900/60'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    {sess.status}
                  </span>

                  {/* Academic Year pill */}
                  <span className="bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded-full px-2.5 py-0.5 text-xs font-mono">
                    🗓️ 2025–2026
                  </span>
                </div>

                {/* Details Row: Date, Teacher, Room */}
                <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-xs text-slate-600 dark:text-slate-300 pt-0.5">
                  <div className="flex items-center gap-1 font-mono">
                    <span>🗓️</span>
                    <span>{sess.date}</span>
                  </div>

                  {sess.teacher && (
                    <div className="flex items-center gap-1 font-medium">
                      <span>👨‍🏫</span>
                      <span>{sess.teacher}</span>
                    </div>
                  )}

                  {sess.room && (
                    <div className="flex items-center gap-1 text-slate-600 dark:text-slate-300">
                      <span>📍</span>
                      <span>{sess.room}</span>
                    </div>
                  )}
                </div>

                {/* Notes container */}
                {sess.notes && (
                  <div className="bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 rounded-xl p-3 text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                    {sess.notes}
                  </div>
                )}

                {/* Action Buttons Toolbar */}
                <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                  {/* Edit button (Purple) */}
                  <button
                    type="button"
                    onClick={() => onEditSession(sess)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors shadow-2xs cursor-pointer"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span>Edit</span>
                  </button>

                  {/* Change Time button (Sky Blue) */}
                  <button
                    type="button"
                    onClick={() => onQuickEditTime(sess)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-sky-500 hover:bg-sky-600 rounded-lg transition-colors shadow-2xs cursor-pointer"
                    title="Change only this session's time independently"
                  >
                    <Clock className="w-3.5 h-3.5" />
                    <span>Change Time</span>
                  </button>

                  {/* Duplicate button (White / Dark border) */}
                  <button
                    type="button"
                    onClick={() => onDuplicateSession(sess)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700/60 border border-slate-200 dark:border-slate-700 rounded-lg transition-colors cursor-pointer"
                  >
                    <Copy className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" />
                    <span>Duplicate</span>
                  </button>

                  {/* Done button (Green) */}
                  <button
                    type="button"
                    onClick={() =>
                      onStatusChange(
                        sess,
                        sess.status === 'Completed' ? 'Scheduled' : 'Completed'
                      )
                    }
                    className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors shadow-2xs cursor-pointer ${
                      isCompleted
                        ? 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                        : 'bg-emerald-500 hover:bg-emerald-600 text-white'
                    }`}
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>{isCompleted ? 'Mark Pending' : 'Done'}</span>
                  </button>

                  {/* Delete button (Red outline) */}
                  <button
                    type="button"
                    onClick={() => onDeleteSession(sess)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 rounded-lg transition-colors cursor-pointer ml-auto"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
