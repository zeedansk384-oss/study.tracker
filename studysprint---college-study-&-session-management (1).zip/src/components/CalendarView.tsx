import React, { useState } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Calendar as CalendarIcon,
  Clock,
  Plus,
  Edit3,
  Trash2,
  MapPin,
  User,
  Check,
  CheckCircle2,
} from 'lucide-react';
import { Session, Subject } from '../types/academic';
import { formatDate, formatTimeRange, formatTime12h } from '../services/storageService';

type CalendarMode = 'daily' | 'weekly' | 'monthly';

interface CalendarViewProps {
  sessions: Session[];
  subjects: Subject[];
  onOpenAddSessionWithDate?: (date: string, startTime?: string) => void;
  onEditSession: (session: Session) => void;
  onQuickEditTime: (session: Session) => void;
  onDeleteSession: (session: Session) => void;
  onToggleComplete: (session: Session) => void;
}

export const CalendarView: React.FC<CalendarViewProps> = ({
  sessions,
  subjects,
  onOpenAddSessionWithDate,
  onEditSession,
  onQuickEditTime,
  onDeleteSession,
  onToggleComplete,
}) => {
  const [mode, setMode] = useState<CalendarMode>('weekly');
  const [currentDate, setCurrentDate] = useState<Date>(new Date());

  const todayStr = formatDate(new Date());

  // Date Navigation
  const handlePrev = () => {
    const d = new Date(currentDate);
    if (mode === 'daily') d.setDate(d.getDate() - 1);
    else if (mode === 'weekly') d.setDate(d.getDate() - 7);
    else d.setMonth(d.getMonth() - 1);
    setCurrentDate(d);
  };

  const handleNext = () => {
    const d = new Date(currentDate);
    if (mode === 'daily') d.setDate(d.getDate() + 1);
    else if (mode === 'weekly') d.setDate(d.getDate() + 7);
    else d.setMonth(d.getMonth() + 1);
    setCurrentDate(d);
  };

  const handleToday = () => {
    setCurrentDate(new Date());
  };

  // Helper: Get start of week (Monday)
  const getStartOfWeek = (d: Date) => {
    const date = new Date(d);
    const day = date.getDay();
    const diff = date.getDate() - day + (day === 0 ? -6 : 1);
    return new Date(date.setDate(diff));
  };

  // Daily View Computations
  const selectedDateStr = formatDate(currentDate);
  const daySessions = sessions
    .filter((s) => s.date === selectedDateStr)
    .sort((a, b) => a.startTime.localeCompare(b.startTime));

  // Weekly View Computations
  const weekStart = getStartOfWeek(currentDate);
  const weekDays = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(weekStart);
    d.setDate(weekStart.getDate() + i);
    return {
      date: d,
      dateStr: formatDate(d),
      dayName: d.toLocaleDateString('en-US', { weekday: 'short' }),
      dayNumber: d.getDate(),
      isToday: formatDate(d) === todayStr,
    };
  });

  // Monthly View Computations
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const firstDayOfMonth = new Date(year, month, 1);
  const lastDayOfMonth = new Date(year, month + 1, 0);

  const startDayIndex = (firstDayOfMonth.getDay() + 6) % 7;
  const daysInMonth = lastDayOfMonth.getDate();

  const monthGridDays: { dateStr: string; dayNumber: number; isCurrentMonth: boolean; isToday: boolean }[] = [];

  const prevMonthLastDay = new Date(year, month, 0).getDate();
  for (let i = startDayIndex - 1; i >= 0; i--) {
    const d = new Date(year, month - 1, prevMonthLastDay - i);
    monthGridDays.push({
      dateStr: formatDate(d),
      dayNumber: prevMonthLastDay - i,
      isCurrentMonth: false,
      isToday: formatDate(d) === todayStr,
    });
  }

  for (let i = 1; i <= daysInMonth; i++) {
    const d = new Date(year, month, i);
    monthGridDays.push({
      dateStr: formatDate(d),
      dayNumber: i,
      isCurrentMonth: true,
      isToday: formatDate(d) === todayStr,
    });
  }

  const remainingCells = 42 - monthGridDays.length;
  for (let i = 1; i <= remainingCells; i++) {
    const d = new Date(year, month + 1, i);
    monthGridDays.push({
      dateStr: formatDate(d),
      dayNumber: i,
      isCurrentMonth: false,
      isToday: formatDate(d) === todayStr,
    });
  }

  return (
    <div className="space-y-5">
      {/* Calendar Header Toolbar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-4 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        {/* Date Navigator */}
        <div className="flex items-center gap-2">
          <div className="flex items-center bg-slate-100 dark:bg-slate-800 rounded-xl p-0.5 border border-slate-200 dark:border-slate-700">
            <button
              onClick={handlePrev}
              type="button"
              className="p-1.5 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white rounded-lg hover:bg-white dark:hover:bg-slate-700 transition-all cursor-pointer"
              title="Previous"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={handleToday}
              type="button"
              className="px-3 py-1 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:text-slate-900 dark:hover:text-white rounded-lg hover:bg-white dark:hover:bg-slate-700 transition-all cursor-pointer"
            >
              Today
            </button>
            <button
              onClick={handleNext}
              type="button"
              className="p-1.5 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white rounded-lg hover:bg-white dark:hover:bg-slate-700 transition-all cursor-pointer"
              title="Next"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <h2 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white ml-2">
            {mode === 'daily' &&
              currentDate.toLocaleDateString('en-US', {
                weekday: 'long',
                month: 'short',
                day: 'numeric',
                year: 'numeric',
              })}
            {mode === 'weekly' && (
              <>
                {weekDays[0].date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} –{' '}
                {weekDays[6].date.toLocaleDateString('en-US', {
                  month: 'short',
                  day: 'numeric',
                  year: 'numeric',
                })}
              </>
            )}
            {mode === 'monthly' &&
              currentDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
          </h2>
        </div>

        {/* View Mode Toggle */}
        <div className="flex items-center gap-2">
          <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-0.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs">
            {(['daily', 'weekly', 'monthly'] as const).map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => setMode(m)}
                className={`px-3.5 py-1.5 font-semibold rounded-lg capitalize transition-all cursor-pointer ${
                  mode === m
                    ? 'bg-white dark:bg-slate-700 text-indigo-700 dark:text-indigo-300 shadow-2xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {m}
              </button>
            ))}
          </div>

          {onOpenAddSessionWithDate && (
            <button
              type="button"
              onClick={() => onOpenAddSessionWithDate(selectedDateStr, '10:00')}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition-all shadow-xs cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>+ Session</span>
            </button>
          )}
        </div>
      </div>

      {/* 1. DAILY VIEW */}
      {mode === 'daily' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs">
          <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/40">
            <div className="flex items-center gap-2">
              <CalendarIcon className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              <span className="text-sm font-bold text-slate-800 dark:text-slate-200">
                {daySessions.length} session{daySessions.length === 1 ? '' : 's'} on {selectedDateStr}
              </span>
            </div>
            {onOpenAddSessionWithDate && (
              <button
                onClick={() => onOpenAddSessionWithDate(selectedDateStr)}
                className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline font-semibold cursor-pointer"
              >
                + Add Session on this day
              </button>
            )}
          </div>

          {daySessions.length === 0 ? (
            <div className="p-12 text-center text-slate-500 dark:text-slate-400 space-y-2">
              <Clock className="w-8 h-8 text-slate-300 dark:text-slate-600 mx-auto" />
              <p className="text-sm font-medium">No sessions scheduled for this day</p>
              {onOpenAddSessionWithDate && (
                <button
                  onClick={() => onOpenAddSessionWithDate(selectedDateStr)}
                  className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline font-semibold cursor-pointer"
                >
                  Schedule a session
                </button>
              )}
            </div>
          ) : (
            <div className="p-4 space-y-3">
              {daySessions.map((sess) => (
                <div
                  key={sess.id}
                  className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm p-4 border-l-4 border-indigo-600 dark:border-indigo-500 space-y-2.5"
                >
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                    <div>
                      <h3 className="text-base font-bold text-slate-900 dark:text-white leading-tight">
                        {sess.title}
                      </h3>
                      <div className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 mt-0.5">
                        {sess.subjectName}
                      </div>
                    </div>

                    <div className="self-start sm:self-auto bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 px-3 py-1 rounded-full text-xs font-mono font-bold flex items-center gap-1.5 shadow-2xs whitespace-nowrap">
                      <Clock className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" />
                      <span>{formatTimeRange(sess.startTime, sess.endTime)}</span>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <span className="bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 border border-blue-200/60 rounded-full px-2.5 py-0.5 text-xs font-semibold">
                      {sess.course}
                    </span>
                    <span className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-full px-2.5 py-0.5 text-xs font-medium">
                      {sess.department}
                    </span>
                    <span className="bg-sky-50 dark:bg-sky-950/40 text-sky-700 dark:text-sky-300 border border-sky-200/60 rounded-full px-2.5 py-0.5 text-xs font-semibold">
                      {sess.sessionType}
                    </span>
                  </div>

                  <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-600 dark:text-slate-300">
                    {sess.room && <span>📍 {sess.room}</span>}
                    {sess.teacher && <span>👨‍🏫 {sess.teacher}</span>}
                  </div>

                  <div className="flex items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                    <button
                      type="button"
                      onClick={() => onEditSession(sess)}
                      className="px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-2xs cursor-pointer flex items-center gap-1.5"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>Edit</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => onQuickEditTime(sess)}
                      className="px-3 py-1.5 text-xs font-semibold text-white bg-sky-500 hover:bg-sky-600 rounded-lg shadow-2xs cursor-pointer flex items-center gap-1.5"
                    >
                      <Clock className="w-3.5 h-3.5" />
                      <span>Change Time</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => onDeleteSession(sess)}
                      className="px-3 py-1.5 text-xs font-medium text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 rounded-lg shadow-2xs cursor-pointer flex items-center gap-1.5 ml-auto"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Delete</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 2. WEEKLY VIEW */}
      {mode === 'weekly' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl overflow-x-auto shadow-xs">
          <div className="min-w-[800px]">
            {/* Week Columns Header */}
            <div className="grid grid-cols-7 border-b border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-800/60 text-center">
              {weekDays.map((wd) => (
                <div
                  key={wd.dateStr}
                  className={`py-3 px-2 border-r border-slate-200 dark:border-slate-800 last:border-r-0 ${
                    wd.isToday ? 'bg-indigo-50/60 dark:bg-indigo-950/40' : ''
                  }`}
                >
                  <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                    {wd.dayName}
                  </div>
                  <div
                    className={`mt-0.5 inline-flex items-center justify-center w-7 h-7 rounded-full text-xs font-bold ${
                      wd.isToday
                        ? 'bg-indigo-600 text-white shadow-xs'
                        : 'text-slate-900 dark:text-white'
                    }`}
                  >
                    {wd.dayNumber}
                  </div>
                </div>
              ))}
            </div>

            {/* Days Content Columns */}
            <div className="grid grid-cols-7 min-h-[480px] divide-x divide-slate-200 dark:divide-slate-800">
              {weekDays.map((wd) => {
                const daySess = sessions
                  .filter((s) => s.date === wd.dateStr)
                  .sort((a, b) => a.startTime.localeCompare(b.startTime));

                return (
                  <div
                    key={wd.dateStr}
                    className={`p-2 space-y-2 flex flex-col justify-between ${
                      wd.isToday ? 'bg-indigo-50/20 dark:bg-indigo-950/20' : ''
                    }`}
                  >
                    <div className="space-y-2 flex-1">
                      {daySess.map((sess) => (
                        <div
                          key={sess.id}
                          className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/90 text-left space-y-1.5 transition-all hover:shadow-xs border-l-4 border-l-indigo-600 dark:border-l-indigo-500"
                        >
                          <div className="flex items-center justify-between text-[10px] font-mono tabular-nums text-slate-500 dark:text-slate-400">
                            <span>{formatTime12h(sess.startTime)}</span>
                            <span className="font-semibold text-indigo-600 dark:text-indigo-400">
                              {sess.sessionType}
                            </span>
                          </div>

                          <div className="text-xs font-bold text-slate-900 dark:text-white leading-tight">
                            {sess.title}
                          </div>

                          <div className="text-[11px] font-semibold text-indigo-600 dark:text-indigo-400 truncate">
                            {sess.subjectName}
                          </div>

                          {sess.room && (
                            <div className="text-[10px] text-slate-400 flex items-center gap-1 truncate">
                              <MapPin className="w-2.5 h-2.5 shrink-0" />
                              <span className="truncate">{sess.room}</span>
                            </div>
                          )}

                          <div className="pt-1.5 flex items-center justify-between border-t border-slate-100 dark:border-slate-700">
                            <button
                              type="button"
                              onClick={() => onQuickEditTime(sess)}
                              className="text-[10px] text-indigo-600 dark:text-indigo-400 hover:underline font-semibold cursor-pointer"
                            >
                              Edit Time
                            </button>
                            <div className="flex items-center gap-1">
                              <button
                                type="button"
                                onClick={() => onEditSession(sess)}
                                className="text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 cursor-pointer"
                                title="Edit"
                              >
                                <Edit3 className="w-3 h-3" />
                              </button>
                              <button
                                type="button"
                                onClick={() => onDeleteSession(sess)}
                                className="text-slate-400 hover:text-rose-600 cursor-pointer"
                                title="Delete"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    {onOpenAddSessionWithDate && (
                      <button
                        type="button"
                        onClick={() => onOpenAddSessionWithDate(wd.dateStr)}
                        className="w-full py-1 text-[11px] font-semibold text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors border border-dashed border-slate-200 dark:border-slate-700 cursor-pointer text-center"
                      >
                        + Add
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* 3. MONTHLY VIEW */}
      {mode === 'monthly' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs">
          <div className="grid grid-cols-7 border-b border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-800/60 text-center font-semibold text-xs text-slate-600 dark:text-slate-300 py-3">
            {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day) => (
              <div key={day}>{day}</div>
            ))}
          </div>

          <div className="grid grid-cols-7 divide-x divide-y divide-slate-100 dark:divide-slate-800">
            {monthGridDays.map((cell) => {
              const daySess = sessions.filter((s) => s.date === cell.dateStr);

              return (
                <div
                  key={cell.dateStr}
                  className={`min-h-[100px] sm:min-h-[120px] p-2 flex flex-col justify-between transition-colors ${
                    !cell.isCurrentMonth
                      ? 'bg-slate-50/50 dark:bg-slate-900/40 text-slate-300 dark:text-slate-600'
                      : cell.isToday
                      ? 'bg-indigo-50/30 dark:bg-indigo-950/20'
                      : 'hover:bg-slate-50/40 dark:hover:bg-slate-800/40'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span
                      className={`text-xs font-bold inline-flex items-center justify-center w-5 h-5 rounded-full ${
                        cell.isToday
                          ? 'bg-indigo-600 text-white'
                          : cell.isCurrentMonth
                          ? 'text-slate-800 dark:text-slate-200'
                          : 'text-slate-400 dark:text-slate-600'
                      }`}
                    >
                      {cell.dayNumber}
                    </span>
                    {onOpenAddSessionWithDate && cell.isCurrentMonth && (
                      <button
                        onClick={() => onOpenAddSessionWithDate(cell.dateStr)}
                        className="text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 p-0.5 rounded cursor-pointer opacity-0 hover:opacity-100 focus:opacity-100 transition-opacity"
                        title={`Add session on ${cell.dateStr}`}
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  <div className="space-y-1 my-1 overflow-hidden">
                    {daySess.slice(0, 3).map((s) => (
                      <button
                        key={s.id}
                        type="button"
                        onClick={() => onEditSession(s)}
                        className="w-full text-left p-1 rounded-md text-[10px] truncate leading-tight flex items-center gap-1 hover:brightness-95 cursor-pointer bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300"
                        title={`${formatTime12h(s.startTime)} - ${s.title}`}
                      >
                        <span className="font-mono tabular-nums font-semibold shrink-0">
                          {formatTime12h(s.startTime)}
                        </span>
                        <span className="truncate font-medium">{s.title}</span>
                      </button>
                    ))}
                    {daySess.length > 3 && (
                      <div className="text-[10px] text-slate-500 dark:text-slate-400 font-semibold px-1">
                        +{daySess.length - 3} more
                      </div>
                    )}
                  </div>

                  <div className="h-1"></div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
